#include<iostream>
#include<string>
#include"Books.h"
#include"Book_Shelf.h"
using namespace std;
void IntializeTheArray(Books* object1, Book_Shelf* object2);
void calculatingNumbers(Book_Shelf* object,int& counter, int& counterOfGener);
int main()
{
	Books object1[20]; Book_Shelf object2[20];  int counterOfGener, counter;
	IntializeTheArray(object1, object2);
	calculatingNumbers(object2,counter, counterOfGener);
	return 0;

	
}
void IntializeTheArray(Books*object1,Book_Shelf*object2)
{
	string scinceFiction = "sci-fci";
	string horror = "Horror";

	for (int i = 0; i < 3; i++)
	{
		object1[i].setGenere(horror);
		object2[i].fillingTheArray(object1);
	}
	for (int i = 3; i < 8; i++)
	{
		object1[i].setGenere(scinceFiction);
		object2[i].fillingTheArray(object1);
	}
	for (int i = 8; i < 20; i++)
	{
		object1[i].setGenere("");
		object2[i].fillingTheArray(object1);
	}
}
void calculatingNumbers(Book_Shelf* object,int& counter, int& counterOfGener)
{
	 int choice;
	string gener;
	cout << "Please Enter the genere you want search for (choose 1/2)" << endl;
	cout << "1.scince fictoin " << endl;
	cout << "2.Horror" << endl;
	cout << "choice :";
		cin >> choice;
		switch (choice)
		{
		case 1:
			gener = "sci-fci";
			break;
		case 2:
			gener = "Horror";
			break;
		default:
			cout << "Enterd wrong choice !!!!!" << endl;
			exit(1);
			break;
		}
	for (int i = 0; i < 9; i++)
	{
		counterOfGener = object[i].countBookbyGenere(gener);
		counter = object[i].countBooksNumbers();
    }
    cout << "There are " << counterOfGener << "  books for " << gener << " ." << endl;
	cout << "The number of books are : " <<counter<<endl;
	object->countRemaingSlots();
}