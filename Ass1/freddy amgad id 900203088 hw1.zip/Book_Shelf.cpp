#include "Book_Shelf.h"
#include"Books.h"
#include<string>
#include<iostream>
using namespace std;
void Book_Shelf :: fillingTheArray(Books* object)
{
	this->arrayOfBooks = object;
}
int Book_Shelf :: countBookbyGenere(string genre)
{
	int counter = 0;
	for (int i = 0; i < 20; i++)
	{
		if (arrayOfBooks[i].getGenere() == genre)
		{
			counter++;
		}
	}
	return counter;
}
int Book_Shelf :: countBooksNumbers()
{
	int counter = 0;
	for (int i = 0; i < 20; i++)
	{
		if (!arrayOfBooks[i].getGenere().empty())
			counter++;
	}
	numberOfBooks = counter;
	return counter;
}
void Book_Shelf :: countRemaingSlots()
{
	int capacity = 20;
	int diffrence = capacity - numberOfBooks;
	if (diffrence >= 0 && diffrence <= 20)
	{
		cout << "There are still " << diffrence << " places empty " << endl;
	}
	else
	{
		cout << "There are no places available " << endl;
		exit(1);
	}

}
