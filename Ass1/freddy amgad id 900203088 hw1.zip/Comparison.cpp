#include "Comparison.h"
#include"House.h"
#include<iostream>
#include<string>
using namespace std;
void Comparison :: FillingArrayOfHouse(House* object)
{
	this->arrayHouse = object;
}
void Comparison :: compare()
{
	int minumum = 1000000;
	for (int i = 0; i < 5; i++)
	{
		if (arrayHouse[i].getTotalPrice() < minumum)
		{
			minumum = arrayHouse[i].getTotalPrice();
		}
	}
	for (int i = 0; i < 5; i++)
	{
		if (arrayHouse[i].getTotalPrice() == minumum)
		{
			cout << "This is the Information of the least priced house....(House Number '" << (i + 1) << "' ) " << endl;
			cout << endl;
			cout << "The number of the floor : " << arrayHouse[i].getFloorNumber() << endl;
			cout << "The price of the meter square : " << arrayHouse[i].getPriceOfMeterSquared() << endl;
			cout << "The space of the House : " << arrayHouse[i].getSpace() << endl;
			cout << "The address of the building : " << arrayHouse[i].getAddress() << endl;
			break;
		}
	}
}