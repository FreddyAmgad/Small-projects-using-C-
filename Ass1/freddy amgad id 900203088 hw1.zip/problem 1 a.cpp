#include<iostream>
using namespace std;
int Countocurence(char array[], int size, int occurance, char target);
char*gettingInfoOfArray(int& size, char& target);
int main()
{
	int size = 0; char target; int occurance = 0;
	char*array=gettingInfoOfArray(size, target);
	cout << "The target '" << target << "' occured " << Countocurence(array, size, occurance, target) <<" times "<< endl;
	delete[] array;
	return 0;
	
}
char*gettingInfoOfArray(int& size,char&target)
{
	cout << "Please enter the number of charecters you want to store" << endl;
	cin >> size;
	 char *array=new char[size];
	cout << "Please Enter the charecters that you want to store in the array" << endl;
	for (int i = 0; i < size; i++)
	{
		cin >> array[i];
	}
	cout << "Please enter the charecter that you want to calculate its occurence " << endl;
	cin >> target;
	return array;
}
int Countocurence(char array[], int size, int occurance, char target)
{
	for (int i = 0; i < size; i++)
	{
		if (array[i] == target)
		{
			occurance++;
		}
	}
	return occurance;
}