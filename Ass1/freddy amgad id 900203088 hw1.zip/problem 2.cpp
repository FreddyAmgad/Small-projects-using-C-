#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
int* FormArray(int&size);
int* reservedArray(int array[], int size);
void DispalyArrays(int array[], int size);
int main()
{
	int size;
	int* array = FormArray(size);
	DispalyArrays(array, size);
	array  = reservedArray(array,size);
	DispalyArrays(array, size);
	delete[] array;
	return 0;
}
int* FormArray(int&size)
{
	cout << "Please enter the size of the array" << endl;
	cin >> size;
	srand(time(0));
	int* array = new int[size];
	for (int i = 0; i < size; i++)
	{
		array[i] = (rand() % size) + 1;
	}

	return array;
}
int*reservedArray(int array[], int size)
{
	int* resrvedarray = new int[size];
	int temporarySize = size;
	for (int i = 0; i < size; i++)
	{
		resrvedarray[i]= array[--temporarySize];
	}
	return resrvedarray;
}
void DispalyArrays(int array[], int size)
{
	cout << "Printing out the array" << endl;
	for (int i = 0; i < size; i++)
	{
		cout << array[i] << endl;
	}
}