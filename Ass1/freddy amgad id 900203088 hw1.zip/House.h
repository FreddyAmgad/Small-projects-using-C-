#pragma once
#include<string>
#include<iostream>
using namespace std;
class House
{
public:
	void setfloorNumber(int floornumber);
	void setSpace(double space);
	void setPriceOfMeterSquared(double priceOfMeterSquared);
	void setAddress(string address);
	int getFloorNumber();
	double getSpace();
	double getPriceOfMeterSquared();
	double getTotalPrice();
	string getAddress();
private:
	int floorNumber;
	double sapce;
	double priceOfMeterSquared;
	double totalPrice;
	string address;
};

