#pragma once
#include"House.h"
#include<string>
#include<iostream>
using namespace std;
class Comparison
{
public:

	void FillingArrayOfHouse(House* object);
		void compare();
private:
	House* arrayHouse;
};

