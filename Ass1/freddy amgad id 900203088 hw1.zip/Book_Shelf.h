#pragma once
#include<string>
#include<iostream>
#include"Books.h"
using namespace std;
class  Book_Shelf
{
public:
	void fillingTheArray(Books* object);
	int countBookbyGenere(string genre);
	int countBooksNumbers();
	void countRemaingSlots();
private:
	Books* arrayOfBooks;
	int numberOfBooks;
};


