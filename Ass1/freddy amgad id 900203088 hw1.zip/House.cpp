#include "House.h"
#include<string>
#include<iostream>
using namespace std;
void House :: setfloorNumber(int floornumber)
{
	this->floorNumber = floornumber;
}
void House :: setSpace(double space)
{
	this->sapce = space;
}
void House :: setPriceOfMeterSquared(double priceOfMeterSquared)
{
	this->priceOfMeterSquared = priceOfMeterSquared;
}
void House :: setAddress(string address)
{
	this->address = address;
}
int House :: getFloorNumber()
{
	return floorNumber;
}
double House :: getSpace()
{
	return sapce;
}
double House :: getPriceOfMeterSquared()
{
	return priceOfMeterSquared;
}
double House ::getTotalPrice()
{
	this->totalPrice = sapce * priceOfMeterSquared;
	return totalPrice;
}
string House :: getAddress()
{
	return address;
}