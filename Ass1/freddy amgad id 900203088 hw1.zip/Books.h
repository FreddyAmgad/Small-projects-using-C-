#pragma once
#include<string>
#include<iostream>
using namespace std;
class Books
{
public:
	void setTitle(string title);
	void setNumberOfPages(int numberOfPages);
	void setGenere(string genere);
	string getTitle();
	int getNumberOfPages();
	string getGenere();
private:
	string title;
	int numberOfPages;
	string genere;
};


