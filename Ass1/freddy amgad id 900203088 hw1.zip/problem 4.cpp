#include<iostream>
#include "House.h"
#include"Comparison.h"
using namespace std;
void takingInfoFromUser(House* object, Comparison*object2);
void diplayingInfo(House* object);
int main()
{
	House object[5]; Comparison object2[5];
	takingInfoFromUser(object,object2);
	diplayingInfo(object);
	object2->compare();	
	return 0;
}
void takingInfoFromUser(House*object,Comparison*object2)
{
	int floornumber; double priceOfMeterSquared, space; string address;
	for (int i = 0; i < 5; i++)
	{
		cout << "Please enter the information of the " << (i + 1) << " house " << endl;
		cout << " Enter the number of the floor : ";
		cin >> floornumber;
		object[i].setfloorNumber(floornumber);
		cout << " Enter the price of the meter square : ";
		cin >> priceOfMeterSquared;
		object[i].setPriceOfMeterSquared(priceOfMeterSquared);
		cout << " Enter the space of the House : ";
		cin >> space;
		cout << "Enter the address of the house : " << endl;
		cin >> address;
		object[i].setAddress(address);
		object[i].setSpace(space);
		object2[i].FillingArrayOfHouse(object);
		cout << "---------------------------------------------------------------------------------" << endl;
	}
}
void diplayingInfo(House* object)
{
	for (int i = 0; i < 5; i++)
	{
		cout << endl;
		cout << "-------------------------------------------------------------------------" << endl;
		cout << "Total price of house " << (i + 1) << " is : " << object[i].getTotalPrice() << endl;
		cout << "---------------------------------------------------------------------------" << endl;
		cout << endl;
	}
}