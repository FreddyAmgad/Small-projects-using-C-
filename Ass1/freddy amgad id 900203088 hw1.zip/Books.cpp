#include "Books.h"
#include<string>
#include<iostream>
using namespace std;
void Books::setTitle(string title)
{
	this->title = title;
}
void Books::setNumberOfPages(int numberOfPages)
{
	this->numberOfPages = numberOfPages;
}
void Books ::setGenere(string genere)
{
	this->genere = genere;
}
string Books:: getTitle()
{
	return title;
}
int Books :: getNumberOfPages()
{
	return numberOfPages;
}
string Books :: getGenere()
{
	return genere;
}