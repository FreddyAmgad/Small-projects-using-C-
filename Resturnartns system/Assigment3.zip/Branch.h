#pragma once
#include<iostream>
#include<string>
#include<fstream>
#include"chef.h"
#include"custmer.h"
#include"delivercustmer.h"
#include"delivery.h"
#include"dineincustmer.h"
#include"menu.h"
#include"order.h"
#include"staff.h"
#include"system.h"
#include"waiter1.h"
#include"worker.h"
using namespace std;
class branch
{
	    string country;
		string adress;
		string brachName;
		int capcity;
		waiter* arrayOfWaitters = new waiter[1];
		chef* arrayOfChefs = new chef[1];
		delivery* arrayOfDeliveryMen = new delivery[1];
		worker* arrayOfWorkers = new worker[1];
	public:
		void setCapacity(int numberOfTables);
			void setAdress(string adress);
			string getAdress();
			void setBranchName(string branchName);
			string getBranchName();
			int getCapacity();
			void staffSignIn(waiter* object1, chef* object2, delivery* object3, worker* object4, branch* info);
			void Diplay(waiter* object1, chef* object2, delivery* object3, worker* object4);
			void FillingBrancjhInfo(branch* info, waiter* object);
			void setCountry(string country);
			string getCountry();
			void setWaiter(waiter* object);
			void setChef(chef* object);
			void setDelivery(delivery* object);
			void setWorker(worker* object);


};

