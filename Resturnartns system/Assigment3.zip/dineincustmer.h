#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
using namespace std;
class dineInCustmer : public custmer
{
		dineInCustmer* arrayOfCustmers;
	public:
		void setAdress(string adress);
			void setTableNumber(int number);
			int getTableNumber();
			void inputOrder(Menu* object);
				void setNumberOfOrders(int number);
				void Display();
				Order* getTheArrayOforders();
				dineInCustmer* getTheArrayOFcustmers();

};

		