#pragma once
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
class Order
{
	private:
		string orderId;
		int tableNumber;
		bool cooked;
		string orderedFood;
		bool delivered;
		bool served;
		int counter ;
	public:
		Order();
		Order(string orderid, int TableNumber, string OrderedFood);
		void setorderId(string orderid);
		void setOrderedFood(string name);
		string getOrderId();
		string getOrderedFood();
		bool IsDelivered();
		void marAsServed(Order* obj, int number, string id);
		void MarkAsCoocked(Order* object, int number, string id);
		void MarkAsDelivered(Order* object, int number, string id);
		bool Iscooked();
		bool IsServed();
};

