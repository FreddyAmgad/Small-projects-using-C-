#include "delivercustmer.h"
	Order* deliverCustmer::getTheArrayOforders()
	{
		return arrayOfOrders;
	}
	deliverCustmer* deliverCustmer::getTheArrayOFcustmers()
	{
		return arrayofcustmers;
	}
	void deliverCustmer::setNumberOfOrders(int number)
	{
		this->numberOfOrders = number;
		arrayOfOrders = new Order[numberOfOrders];
		arrayofcustmers = new deliverCustmer[numberOfOrders];
	}
	void deliverCustmer::inputOrder(Menu* object)
	{
		string orderId, adress;
		int tableNumber, choice, number;
		cout << "Please Enter the number of orders you want :";
		cin >> number;
		setNumberOfOrders(number);
		for (int i = 0; i < numberOfOrders; i++)
		{
			cout << "Please enter the ID of the order :";
			cin >> orderId;
			arrayOfOrders[i].setorderId(orderId);
			arrayOfOrders[i].setOrderedFood(object->ordersavailable());
			cout << "Please enter the address of the home that  you want :";
			cin >> adress;
			arrayofcustmers[i].setAdress(adress);
		}

	}
	void deliverCustmer::setAdress(string adress)
	{
		this->adress = adress;
	}
	string deliverCustmer::getadress()
	{
		return adress;
	}
	void deliverCustmer::setTime(int number)
	{
		this->time = number;
	}
	int deliverCustmer::getTime()
	{
		return time;
	}
	
	void deliverCustmer::setTableNumber(int number)
	{
		tableNumber = 0;
	}
	void deliverCustmer::Display()
	{
		for (int i = 0; i < numberOfOrders; i++)
		{
			cout << " ID of the order :" << arrayOfOrders[i].getOrderId() << endl;
			cout << "Name of the food :" << arrayOfOrders[i].getOrderedFood() << endl;
		}
	}