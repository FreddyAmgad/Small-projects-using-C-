#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
#include"system.h"
#include"delivercustmer.h"
#include"dineincustmer.h"
#include"staff.h"
using namespace std;

class delivery:public staff
{
	public:
		    void login();
			void viewduties();
			void deliveryfillingArrayOfInfo();
			void setId(string id);
			void setBranchName(string name);
			void setSalary(int salary);
			void setNumberOfWorkDone(int number);
			int getNumberOfWorkDone();
			string getId();
			string getBranchName();
			double getSalary();
			void MarkAsDelivered(Order* object);
			void changeDataInFile();

};

