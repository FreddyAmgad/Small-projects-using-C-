#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
#include"system.h"
#include"delivercustmer.h"
#include"dineincustmer.h"
#include"staff.h"
#include"Clean.h"
using namespace std;

class worker :public staff
{
	int NumberOfBathroomCleaned;
	int NumberOfDishesCleaned;
public:
	void changeDataInFile();
	void login();
	void viewduties();
	void workerfillingArrayOfInfo();
	void setNumberOfBathroomCleaned(int number);
	void setNumberOfDishesCleaned(int number);
	int getNumberOfBathroomCleaned();
	int getNumberOfDishesCleaned();
	void setNumberOfWorkDone(int number);
	int getNumberOfWorkDone();
	void setId(string id);
	void setBranchName(string name);
	void setSalary(int salary);
	string getId();
	string getBranchName();
	double getSalary();
	void MarkAsCleaned(Clean* object);
};

