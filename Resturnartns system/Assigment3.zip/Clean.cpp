#include "Clean.h"

Clean::Clean()
	{
		cleanedBathrooms = false;
		cleanedDishes = false;
	}
	void Clean::MarkBathroomsAsCleaned(Clean* object, int number)
	{
		for (int i = 0; i < number; i++)
		{
			object[i].cleanedBathrooms = true;
		}
	}
	void Clean::MarkDishesAsCleaned(Clean* object, int number)
	{
		for (int i = 0; i < number; i++)
		{
			object[i].cleanedDishes = true;
		}
	}
	bool Clean::IsBathroomsCleaned()
	{
		return cleanedBathrooms;
	}
	bool Clean::IsDishesCleaned()
	{
		return cleanedDishes;
	}