#include "menu.h"
string Menu::ordersavailable()
{
	string orderedFood;
	int choice;
	cout << "<<Please choose the numbers of the dishes that you need (choose in numbers from 1 to 5)>>)" << endl;
	cout << "1-SALAMON DISH" << endl;
	cout << "2-BEEF DISH" << endl;
	cout << "3-BURGER DISH" << endl;
	cout << "4-SALAMI DISH" << endl;
	cout << "5-PIZZA DISH" << endl;
	cout << endl;
	cout << "Choice :";
	cin >> choice;
	switch (choice)
	{
	case 1:
		orderedFood = "SALAMON DISH";
		return orderedFood;
		break;
	case 2:
		orderedFood = "BEEF DISH";
		return orderedFood;
		break;
	case 3:
		orderedFood = "BURGER DISH";
		return orderedFood;
		break;
	case 4:
		orderedFood = "SALAMI DISH";
		return orderedFood;
		break;
	case 5:
		orderedFood = "PIZZA DISH";
		return orderedFood;
		break;
	default:
		cout << "Wrong choice!!" << endl;
		exit(1);
		break;
	}

}		