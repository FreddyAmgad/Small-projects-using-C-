#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
#include"system.h"
#include"delivercustmer.h"
#include"dineincustmer.h"
#include"staff.h"
using namespace std;

class chef:public staff
{
	public:
		void changeDataInFile();
			void login();
			void viewduties();
			void cheffillingArrayOfInfo();
			void setNumberOfWorkDone(int number);
			int getNumberOfWorkDone();
			void setId(string id);
			void setBranchName(string name);
			void setSalary(int salary);
			string getId();
			string getBranchName();
			double getSalary();
			void MarkAscooked(Order* object);
			void Display();

};

