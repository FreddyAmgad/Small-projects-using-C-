#pragma once
class Clean
{
	private:
		bool cleanedBathrooms;
		bool	cleanedDishes;
	public:
		Clean();
		void MarkBathroomsAsCleaned(Clean* object, int number);
		void MarkDishesAsCleaned(Clean* object, int number);
		bool IsBathroomsCleaned();
		bool IsDishesCleaned();
};

