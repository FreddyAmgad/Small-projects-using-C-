#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
Order::Order()
	{
		orderId = "";
		orderedFood = "";
		delivered = false;
		cooked = false;
		served = false;
		counter = 0;
		tableNumber = -1;
	}
Order::Order(string orderid, int TableNumber, string OrderedFood)
	{
		delivered = false;
		orderId = orderid;
		tableNumber = TableNumber;
		orderedFood = OrderedFood;
	}
void Order::setorderId(string orderid)
	{
		this->orderId = orderid;
	}
	void Order::setOrderedFood(string name)
	{
		this->orderedFood = name;
	}
	string Order::getOrderId()
	{
		return orderId;
	}

	string Order::getOrderedFood()
	{
		return orderedFood;
	}
	bool Order::IsDelivered()
	{
		return delivered;
	}
	void Order::marAsServed(Order* obj, int number, string id)
	{
		for (int i = 0; i < number; i++)
		{
			if (obj[i].getOrderId() == id)
			{
				obj[i].served = true;
			}
		}

	}
	void Order::MarkAsCoocked(Order* object, int number, string id)
	{
		for (int i = 0; i < number; i++)
		{
			if (object[i].getOrderId() == id)
			{
				object[i].cooked = true;
			}
		}
	}
	void Order::MarkAsDelivered(Order* object, int number, string id)
	{
		for (int i = 0; i < number; i++)
		{
			if (object[i].getOrderId() == id)
			{
				object[i].delivered = true;
			}
		}
	}

	bool Order:: Iscooked()
	{
		return cooked;
	}
	bool Order::IsServed()
	{
		return served;
	}
	