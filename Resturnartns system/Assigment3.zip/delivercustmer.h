#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
using namespace std;
class deliverCustmer: public custmer
{
		deliverCustmer* arrayofcustmers;
		int time;
	public:
		Order* getTheArrayOforders();
			deliverCustmer* getTheArrayOFcustmers();
			void setNumberOfOrders(int number);
			void inputOrder(Menu* object);
			void setAdress(string adress);
			string getadress();
			void setTableNumber(int number);
			void setTime(int number);
			int getTime();
			void Display();

};

