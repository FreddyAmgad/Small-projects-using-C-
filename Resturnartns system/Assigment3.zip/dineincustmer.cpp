#include "dineincustmer.h"
	void dineInCustmer::setAdress(string adress)
	{
		adress = "";
	}
	void dineInCustmer::setTableNumber(int number)
	{
		this->tableNumber = number;
	}
	int dineInCustmer::getTableNumber()
	{		return tableNumber;
	}
	void dineInCustmer::inputOrder(Menu* object)
	{
		string orderId; int number;
		int tableNumber, choice;
		cout << "Please Enter the number of orders you want :";
		cin >> number;
		setNumberOfOrders(number);
		for (int i = 0; i < numberOfOrders; i++)
		{
			cout << "Please enter the ID of the order :";
			cin >> orderId;
			arrayOfOrders[i].setorderId(orderId);
			arrayOfOrders[i].setOrderedFood(object->ordersavailable());
			cout << "Please enter the number of the table that  you want :";
			cin >> tableNumber;
			arrayOfCustmers[i].setTableNumber(tableNumber);
			
		}

	}
	void dineInCustmer::setNumberOfOrders(int number)
	{
		this->numberOfOrders = number;
		arrayOfOrders = new Order[numberOfOrders];
		arrayOfCustmers = new dineInCustmer[numberOfOrders];
	}
	void dineInCustmer::Display()
	{
		for (int i = 0; i < numberOfOrders; i++)
		{
			cout << " ID of the order :" << arrayOfOrders[i].getOrderId() << endl;
			cout << "Name of the food :" << arrayOfOrders[i].getOrderedFood() << endl;
		}
	}
	Order* dineInCustmer::getTheArrayOforders()
	{
		return arrayOfOrders;
	}
	dineInCustmer* dineInCustmer::getTheArrayOFcustmers()
	{
		return arrayOfCustmers;
	}
