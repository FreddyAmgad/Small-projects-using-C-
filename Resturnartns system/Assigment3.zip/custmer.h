#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
using namespace std;
class custmer
{
protected:
	int tableNumber;
	string adress;
	Order* arrayOfOrders;
	int numberOfOrders;
public:
	void virtual inputOrder(Menu * object) = 0;
	void virtual setAdress(string adress) = 0;
	void virtual setTableNumber(int number) = 0;
};

