#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
#include"system.h"
#include"delivercustmer.h"
#include"dineincustmer.h"
using namespace std;
class staff:public system
	
{

protected:
	int numberOfDelivered;
	int  workDone;
	string id, branchName;
	int salary;
	Order* arrayOfOrders;
public:
	void  viewduties() = 0;
	void login() = 0;
	void  changeDataInFile() = 0;
};

