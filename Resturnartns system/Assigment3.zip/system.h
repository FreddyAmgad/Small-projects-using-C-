#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
#include"menu.h"
#include"custmer.h"
using namespace std;
class system
{
	protected:
		bool succedLogin = false;
	public:
		void virtual viewduties() = 0;
		void virtual login() = 0;
		void virtual changeDataInFile() = 0;
};

