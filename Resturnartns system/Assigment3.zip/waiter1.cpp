#include "waiter1.h"
	void waiter::changeDataInFile()
	{
		ofstream write;
		write.open("Waiter.txt", ios::trunc);
		if (write.fail())
			cout << "Failled to open" << endl;
		write << getId() << ":" << getBranchName() << ":" << getSalary() << ":" << getNumberOfWorkDone() + numberOfDelivered << endl;
		write.close();
	}
	void waiter::login()
	{
		string id;
		cout << "Please Enter the your ID :";
		cin >> id;
		if (id == getId())
		{
			this->succedLogin = true;
		}
		else
		{
			cout << "No one in the staff with this information try again please " << endl;
			exit(1);
		}
	}
	void waiter::viewduties()
	{
		cout << "A waiter must do more than simply transfer the cooked food to the custmers.In this job,you're a caretaker of others' food, and your company's money and name. To perform your duties safely, promptly, you need good communtication skills, and well-groomed appearance" << endl;
	}
	void waiter::fillingArrayOfInfo()
	{
		string token;
		ifstream read;
		read.open("Waiter.txt");
		if (read.fail())
			cout << "Failled to open" << endl;
		for (int i = 0; i < 4; i++)
		{
			getline(read, token, ':');
			switch (i)
			{
			case 0:
				setId(token);
				break;
			case 1:
				setBranchName(token);
				break;
			case 2:
				setSalary(stoi(token));
				break;
			case 3:
				setNumberOfWorkDone(stoi(token));
				break;
			default:
				break;
			}
		}
		read.close();
	}
	void waiter::setId(string id)
	{
		this->id = id;
	}
	void waiter::setBranchName(string name)
	{
		this->branchName = name;
	}
	void waiter::setSalary(int salary)
	{
		this->salary = salary;
	}
	void waiter::setNumberOfWorkDone(int number)
	{
		this->workDone = number;
	}
	int waiter::getNumberOfWorkDone()
	{
		return workDone;
	}
	string waiter::getId()
	{
		return id;
	}
	string waiter::getBranchName()
	{
		return branchName;
	}
	double waiter::getSalary()
	{
		return salary;
	}
	void waiter::MarkAsServed(Order* object)
	{
		int number = 0; string id;
		cout << "Waiter Please Enter the number of the served orders :";
		cin >> number;
		numberOfDelivered = number;
		for (int i = 0; i < number; i++)
		{
			cout << "Waiter Please Enter the ID of the served orders :" << endl;
			cin >> id;
			object->marAsServed(object, number, id);
		}
	}