#include "worker.h"

	void worker::changeDataInFile()
	{
		ofstream write;
		write.open("worker.txt", ios::trunc);
		if (write.fail())
			cout << "Failled to open" << endl;
		write << getId() << ":" << getBranchName() << ":" << getSalary() << ":" << getNumberOfBathroomCleaned()<<":"<< getNumberOfDishesCleaned ()<< endl;
		write.close();
	}
	void worker::login()
	{
		string id;
		cout << "Please Enter the your ID :";
		cin >> id;
		if (id == getId())
		{
			this->succedLogin = true;
		}
		else
		{
			cout << "No one in the staff with this information try again please " << endl;
			exit(1);
		}
	}
	void worker::viewduties()
	{
		cout << "A worker must clean out dishes and clean the resturant table" << endl;

	}
	void worker::workerfillingArrayOfInfo()
	{
			string token;
			ifstream read;
			read.open("worker.txt");
			if (read.fail())
				cout << "Failled to open" << endl;
			for (int i = 0; i < 5; i++)
			{
				getline(read, token, ':');
				switch (i)
				{
				case 0:
					setId(token);
					break;
				case 1:
					setBranchName(token);
					break;
				case 2:
					setSalary(stoi(token));
					break;
				case 3:
					setNumberOfBathroomCleaned(stoi(token));
					break;
				case 4:
					setNumberOfDishesCleaned(stoi(token));
					break;
				default:
					break;
				}
			}
			read.close();
		
	}
	void worker::setNumberOfWorkDone(int number)
	{
		this->workDone = number;
	}
	int worker::getNumberOfWorkDone()
	{
		return workDone;
	}
	void worker::setId(string id)
	{
		this->id = id;
	}
	void worker::setBranchName(string name)
	{
		this->branchName = name;
	}
	void worker::setSalary(int salary)
	{
		this->salary = salary;
	}
	string worker::getId()
	{
		return id;
	}
	string worker::getBranchName()
	{
		return branchName;
	}
	double worker::getSalary()
	{
		return salary;
	}
	void worker::MarkAsCleaned(Clean* object)
	{
		int number = 0; 
		cout << "Worker Please Enter the number of cleaned Bathrooms :";
		cin >> number;
		setNumberOfBathroomCleaned(getNumberOfBathroomCleaned() + number);
		for (int i = 0; i < number; i++)
		{
			object->MarkBathroomsAsCleaned(object,number);
		}
		cout << "Waiter Please Enter the number of Cleaned Dishes :";
		cin >> number;
		setNumberOfDishesCleaned(getNumberOfDishesCleaned() + number);
		for (int i = 0; i < number; i++)
		{
			object->MarkDishesAsCleaned(object, number);
		}
	}
	void worker::setNumberOfDishesCleaned(int number)
	{
		this->NumberOfDishesCleaned = number;
	}
	void worker::setNumberOfBathroomCleaned(int number)
	{
		this->NumberOfBathroomCleaned = number;
	}
	int worker::getNumberOfDishesCleaned()
	{
		return NumberOfDishesCleaned;
	}
	int worker::getNumberOfBathroomCleaned()
	{
		return NumberOfBathroomCleaned;
	}