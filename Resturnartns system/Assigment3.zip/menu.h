#pragma once
#include "order.h"
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
class Menu
{
public:
	string ordersavailable();

};

