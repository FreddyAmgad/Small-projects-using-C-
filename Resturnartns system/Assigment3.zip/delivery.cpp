#include "delivery.h"

	void delivery::login()
	{
		string id;
		cout << "Please Enter the your ID :";
		cin >> id;
		if (id == getId())
		{
			this->succedLogin = true;
		}
		else
		{
			cout << "No one in the staff with this information try again please " << endl;
			exit(1);
		}
	}

	void delivery::viewduties()
	{
		cout << "A delivery person must do more than simply transport items from one place to another. In this job, you're a caretaker of others' food, and your company's money and name. To perform your duties safely, promptly, you need good driving skills, and navigation and organization skills" << endl;
	}
	void delivery::deliveryfillingArrayOfInfo()
	{
		string token;
		ifstream read;
		read.open("delivery.txt");
		if (read.fail())
			cout << "Failled to open" << endl;
		for (int i = 0; i < 4; i++)
		{
			getline(read, token, ':');
			switch (i)
			{
			case 0:
				setId(token);
				break;
			case 1:
				setBranchName(token);
				break;
			case 2:
				setSalary(stoi(token));
				break;
			case 3:
				setNumberOfWorkDone(stoi(token));
				break;
			default:
				break;
			}
		}
		read.close();
	}
	void delivery::setNumberOfWorkDone(int number)
	{
		this->workDone = number;
	}
	int delivery::getNumberOfWorkDone()
	{
		return workDone;
	}
	void delivery::setId(string id)
	{
		this->id = id;
	}
	void delivery::setBranchName(string name)
	{
		this->branchName = name;
	}
	void delivery::setSalary(int salary)
	{
		this->salary = salary;
	}
	string delivery::getId()
	{
		return id;
	}
	string delivery::getBranchName()
	{
		return branchName;
	}
	double delivery::getSalary()
	{
		return salary;
	}
	void delivery::MarkAsDelivered(Order* object)
	{
		int number = 0; string id;
		cout << "Delivery Please Enter the number of the Delivered orders :";
		cin >> number;
		numberOfDelivered = number;
		for (int i = 0; i < number; i++)
		{
			cout << "Delivery Please Enter the ID of the Delivered orders :" << endl;
			cin >> id;
			object->MarkAsDelivered(object, number, id);
		}
	}
	void delivery::changeDataInFile()
	{
		ofstream write;
		write.open("delivery.txt", ios::trunc);
		if (write.fail())
			cout << "Failled to open" << endl;
		write << getId() << ":" << getBranchName() << ":" << getSalary() << ":" << getNumberOfWorkDone() + numberOfDelivered << endl;
		write.close();
	}