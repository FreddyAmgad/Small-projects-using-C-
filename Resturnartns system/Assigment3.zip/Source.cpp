#include<iostream>
#include<string>
#include<fstream>
#include"chef.h"
#include"custmer.h"
#include"delivercustmer.h"
#include"delivery.h"
#include"dineincustmer.h"
#include"menu.h"
#include"order.h"
#include"staff.h"
#include"system.h"
#include"waiter1.h"
#include"worker.h"
#include"Branch.h"
#include"Clean.h"
using namespace std;

void Diplay(Order* object1, Clean* object2);
void MakingTheOrder1(waiter* object1, chef* object2, delivery* object3, worker* object4, dineInCustmer* object5, deliverCustmer* object6, Order* object7, Clean* object8, int&choice);
void FillingTheInfoOfTheUser(int&choice, dineInCustmer* object1, deliverCustmer* object2, Menu* object3, branch* object4,Order* object5);
void Diplay(waiter* object1, chef* object2, delivery* object3, worker* object4, dineInCustmer* object5, deliverCustmer* object6, int choice);
void MakingTheOrder(waiter* object1, chef* object2, delivery* object3, worker* object4, dineInCustmer* object5, deliverCustmer* object6, Menu* object7, branch* object8, Order* object9, Clean* object10, int&choice);
int main()
{
	int choice = 0; waiter* object1 = new waiter; chef* object2 = new chef; delivery* object3 = new delivery; worker* object4 = new worker; dineInCustmer* object5 = new dineInCustmer; Menu* object6 = new Menu; Order* object7 = new Order; deliverCustmer* object8 = new deliverCustmer; branch* object9 = new branch; Clean* object10 = new Clean;
	int choice1 = 0; waiter* object11 = new waiter; chef* object12 = new chef; delivery* object13 = new delivery; worker* object14 = new worker; dineInCustmer* object15 = new dineInCustmer; Menu* object16 = new Menu; Order* object17 = new Order; deliverCustmer* object18 = new deliverCustmer; branch* object19 = new branch; Clean* object20 = new Clean;
	MakingTheOrder(object1, object2, object3, object4, object5, object8, object6, object9, object7,object10,choice);
	MakingTheOrder(object11, object12, object13, object14, object15, object18, object16, object19, object17, object20, choice1);

	 return 0;
}
void Diplay(Order* object1,Clean*object2)
{
	cout << "IScooked ::" << boolalpha << object1->Iscooked() << endl;
	cout << "ISDelivered ::" << boolalpha << object1->IsDelivered() << endl;
	cout << "IsServed ::" << boolalpha << object1->IsServed() << endl;
	cout << "IsBathroomsCleaned ::" << boolalpha << object2->IsBathroomsCleaned() << endl;
	cout << "IsDishesCleaned ::" << boolalpha << object2->IsDishesCleaned() << endl;
}
void MakingTheOrder1(waiter* object1, chef* object2, delivery* object3, worker* object4, dineInCustmer* object5, deliverCustmer* object6, Order* object7, Clean*object8,int&choice)
{

	if (choice == 1)
	{
		object7 = object5->getTheArrayOforders();
		cout << "\n\n\nBEFORE MARKING THEM AS READY BY THE STAFF\n\n";
		Diplay(object7,object8);
		object2->MarkAscooked(object7);
		object1->MarkAsServed(object7);
		object4->MarkAsCleaned(object8);
		cout << "\n\n\nAFTER MARKING THEM AS READY BY THE STAFF\n\n";
		Diplay(object7,object8);

	}
	else if (choice == 2)
	{
		object7 = object6->getTheArrayOforders();
		cout << "\n\n\nBEFORE MARKING THEM AS READY BY THE STAFF\n\n";
		Diplay(object7,object8);
		object2->MarkAscooked(object7);
		object3->MarkAsDelivered(object7);
		object4->MarkAsCleaned(object8);
		cout << "\n\n\nAFTER MARKING THEM AS READY BY THE STAFF\n\n";
		Diplay(object7,object8);
	}
}
void FillingTheInfoOfTheUser(int&choice,dineInCustmer* object1, deliverCustmer* object2,Menu*object3, branch*object4,  Order* object5)
{
	cout << "<<<<<<<<<<<<<<<<<<<<Welcome to our resturant>>>>>>>>>>>>>>>>>>>\n\n\n\n" << endl;
	cout << "<<<<<<<<<<<<<<<<<<<<Please choose 1 if your are DineInCustmer or 2 if you are Delivery custmer>>>>>>>>>>>>>>>>>>> :";
	cin >> choice;
	if (choice == 1)
	{
		dineInCustmer* ptr = new dineInCustmer;
		object1->inputOrder(object3);
		cout << "\n\n\n\n<<<<<<<<<<<<<<<<<<<<Please Enter the country of the Branch>>>>>>>>>>>>>>>>>>>" << endl;
		string country;
		cin >> country;
		object4->setCountry(country);
		object1 = object1->getTheArrayOFcustmers();
		cout << "\n\Please go to table number:" << object1->getTableNumber() << endl;
		return;
	}
	if (choice == 2)
	{
		string adress; int time;
		object2->inputOrder(object3);
		cout << "\n\n\n\n<<<<<<<<<<<<<<<<<<<<Please Enter the country of the Branch>>>>>>>>>>>>>>>>>>>" << endl;
		string country;
		cin >> country;
		object4->setCountry(country);
		cout << "\n\n\n\n<<<<<<<<<<<<<<<<<<<<Please Enter the Time you need the order at>>>>>>>>>>>>>>>>>>>" << endl;
		cin >> time;
		object2->setTime(time);
		object2 = object2->getTheArrayOFcustmers();
		cout << "\n\the order will arrive soon at:" << object2->getadress() << endl;
		return;
	}
} 
void EndingTheSystem(waiter* object1, chef* object2, delivery* object3, worker* object4)
{
	object1->changeDataInFile();
	object2->changeDataInFile();
	object3->changeDataInFile();
	object4->changeDataInFile();
	return;
}
void Diplay(waiter* object1, chef* object2, delivery* object3, worker* object4,dineInCustmer*object5,deliverCustmer*object6,int choice)
{
	cout << object1->getId() << object1->getBranchName() <<object1->getSalary()<<object1->getNumberOfWorkDone() << endl;
	cout << object2->getId() << object2->getBranchName() << object2->getSalary() << object2->getNumberOfWorkDone() << endl;
	cout << object3->getId() << object3->getBranchName() << object3->getSalary() << object3->getNumberOfWorkDone() << endl;
	cout << object4->getId() << object4->getBranchName() << object4->getSalary() << object4->getNumberOfBathroomCleaned()<<object4->getNumberOfDishesCleaned() << endl;
	cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
	if (choice == 1)
		object5->Display();
	else if (choice == 2)
		object6->Display();
}
void MakingTheOrder(waiter* object1, chef* object2, delivery* object3, worker* object4, dineInCustmer* object5, deliverCustmer* object6, Menu* object7,branch*object8,Order*object9, Clean* object10, int&choice)
{
	object8->staffSignIn(object1, object2, object3, object4,object8);
	FillingTheInfoOfTheUser(choice, object5, object6, object7,object8,object9);
	MakingTheOrder1(object1, object2, object3, object4, object5, object6, object9,object10,choice);
	Diplay(object1, object2, object3, object4, object5,object6,choice);
	EndingTheSystem(object1,object2,object3,object4);
}
