#include "chef.h"
	void chef::changeDataInFile()
	{
		ofstream write;
		write.open("chef.txt", ios::trunc);
		if (write.fail())
			cout << "Failled to open" << endl;
		write << getId() << ":" << getBranchName() << ":" << getSalary() << ":" << getNumberOfWorkDone() + numberOfDelivered << endl;
		write.close();
	}
	void chef::login()
	{
		string id;
		cout << "Please Enter the your ID :";
		cin >> id;
		if (id == getId())
		{
			this->succedLogin = true;
		}
		else
		{
			cout << "No one in the staff with this information try again please " << endl;
			exit(1);
		}
	}
	void chef::viewduties()
	{
		cout << "A chef person must do more than just cooking the food In this job, you're the maker of others' food, and you are responsible for your  company's money and name.To perform your duties safely, promptly, you need good cooking skills. " << endl;
	}
	void chef::cheffillingArrayOfInfo()
	{
		string token;
		ifstream read;
		read.open("chef.txt");
		if (read.fail())
			cout << "Failled to open" << endl;
		for (int i = 0; i < 4; i++)
		{
			getline(read, token, ':');
			switch (i)
			{
			case 0:
				setId(token);
				break;
			case 1:
				setBranchName(token);
				break;
			case 2:
				setSalary(stoi(token));
				break;
			case 3:
				setNumberOfWorkDone(stoi(token));
				break;
			default:
				break;
			}
		}
		read.close();
	}
	void chef::setNumberOfWorkDone(int number)
	{
		this->workDone = number;
	}
	int chef::getNumberOfWorkDone()
	{
		return workDone;
	}
	void chef::setId(string id)
	{
		this->id = id;
	}
	void chef::setBranchName(string name)
	{
		this->branchName = name;
	}
	void chef::setSalary(int salary)
	{
		this->salary = salary;
	}
	string chef::getId()
	{
		return id;
	}
	string chef::getBranchName()
	{
		return branchName;
	}
	double chef::getSalary()
	{
		return salary;
	}
	void chef::MarkAscooked(Order* object)
	{
		int number = 0; string id;
		cout << "chef Please Enter the number of the served orders :";
		cin >> number;
		numberOfDelivered = number;
		for (int i = 0; i < number; i++)
		{
			cout << "chef Please Enter the ID of the served orders :" << endl;
			cin >> id;
			object->MarkAsCoocked(object, number, id);
		}
	}
	void chef::Display()
	{
		cout << getId() << endl;
		cout << getSalary() << endl;
		cout << getBranchName() << endl;
		cout << getNumberOfWorkDone() << endl;
		cout << numberOfDelivered << endl;
		cout << boolalpha << succedLogin << endl;
	}
