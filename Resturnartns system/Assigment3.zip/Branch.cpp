#include "Branch.h"
	void branch::setCapacity(int numberOfTables)
	{
		this->capcity = numberOfTables;
	}
	void branch::setAdress(string adress)
	{
		this->adress = adress;
	}
	string branch::getAdress()
	{
		return adress;
	}
	void branch::setBranchName(string branchName)
	{
		this->brachName = branchName;
	}
	string branch::getBranchName()
	{
		return brachName;
	}
	int branch::getCapacity()
	{
		return capcity;
	}
	void branch::setWaiter(waiter* object)
	{
		this->arrayOfWaitters = object;
	}
	void branch::setChef(chef* object)
	{
		this->arrayOfChefs = object;
	}
	void branch::setWorker(worker* object)
	{
		this->arrayOfWorkers = object;
	}
	void branch::setDelivery(delivery* object)
	{
		this->arrayOfDeliveryMen = object;
	}
	void branch::staffSignIn(waiter* object1, chef* object2, delivery* object3, worker* object4, branch* info)
	{
		object1->fillingArrayOfInfo(); object2->cheffillingArrayOfInfo(); object3->deliveryfillingArrayOfInfo(); object4->workerfillingArrayOfInfo();
		FillingBrancjhInfo(info, object1);
		info->setWaiter(object1);
		info->setChef(object2);
		info->setDelivery(object3);
		info->setWorker(object4);
		cout << "<<<<<<<<<<<<<<<<<<<<Please Waiter SignIn to the system>>>>>>>>>>>>>>>>>>>\n\n\n\n" << endl;
		arrayOfWaitters->login();
		cout << "<<<<<<<<<<<<<<<<<<<<Please chef SignIn to the system>>>>>>>>>>>>>>>>>>>\n\n\n\n" << endl;
		arrayOfChefs->login();
		cout << "<<<<<<<<<<<<<<<<<<<<Please delivery SignIn to the system>>>>>>>>>>>>>>>>>>>\n\n\n\n" << endl;
		arrayOfDeliveryMen->login();
		cout << "<<<<<<<<<<<<<<<<<<<<Please worker SignIn to the system>>>>>>>>>>>>>>>>>>>\n\n\n\n" << endl;
		arrayOfWorkers->login();
	}
	void branch::Diplay(waiter* object1, chef* object2, delivery* object3, worker* object4)
	{
		cout << object1->getId() << object1->getBranchName() << object1->getSalary() << object1->getNumberOfWorkDone() << endl;
		cout << object2->getId() << object2->getBranchName() << object2->getSalary() << object2->getNumberOfWorkDone() << endl;
		cout << object3->getId() << object3->getBranchName() << object3->getSalary() << object3->getNumberOfWorkDone() << endl;
		cout << object4->getId() << object4->getBranchName() << object4->getSalary() << object4->getNumberOfWorkDone() << endl;
		cout << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
	}
	void branch::FillingBrancjhInfo(branch* info, waiter* object)
	{
		string adress; int capacity = 20;
		cout << "Please Enter The adress of The Branch :";
		cin >> adress;
		info->setAdress(adress);
		info->setBranchName(object->getBranchName());
		info->setCapacity(capacity);
	}
	void branch::setCountry(string country)
	{
		this->country = country;
	}
	string branch::getCountry()
	{
		return country;
	}