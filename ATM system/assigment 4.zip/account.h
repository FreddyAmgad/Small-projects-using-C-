#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"Atm.h"
using namespace std;
class card
{
	int NumberOfcard;
public:
	card();
	card(int number);
	void	setNumber(int number);
	int getNumberOfCard();
};
struct accountNode
{
	string numberOfTheAccount;
	string typeOfAccount;
	int balanceOfTheAccount;
	card arrayOfCards[2];
	accountNode* next;
	accountNode();
	accountNode(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount);
	
};
class accountlist
{
private:
	accountNode* head;
	accountNode* tail;
public:
	accountlist();
	accountNode* searchForNode();
		void deletecustmerInCertainPos(int pos);
		void FillingTheList();
		void deletFirst();
		void deleteLast();
		bool checkIfExisit(string name);
		void createAccount();
		void changeDataInFile(vector <string> numberOfTheAccount, vector <string> typeOfAccount, vector <int> balanceOfTheAccount);
		void withdrew(atmList object);
		void deposite(atmList object);
		void insert(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount);
		void Display();
		~accountlist();
		void createNumberOfTheAccountVector(vector <string>& numberOfTheAccount, vector <string>& typeOfAccount, vector <int>& balanceOfTheAccount);
		void takingACCInfo(string& numberOfTheAccount, string& typeOfAccount, int& balanceOfTheAccount);
		
};

