#include "Atm.h"
atmNode::atmNode()
{
	this->amountOftransaction = 0;
	this->cardNumber = 0;
	this->locationOfAtm = "";
	this->transactionitDate = "";
	this->transactionTime = "";

}
atmNode::atmNode(string transactionitDate, string transactionTime, string locationOfAtm, int amountOftransaction, int cardNumber)
{
	this->amountOftransaction = amountOftransaction;
	this->cardNumber = cardNumber;
	this->locationOfAtm = locationOfAtm;
	this->transactionitDate = transactionitDate;
	this->transactionTime = transactionTime;
}
atmList::atmList()
{
	head = NULL;
	tail = NULL;
}
void atmList::insert(string transactionitDate, string transactionTime, string locationOfAtm, int amountOftransaction, int cardNumber)
{
	atmNode* NewNode = new atmNode(transactionitDate, transactionTime, locationOfAtm, amountOftransaction, cardNumber);
	if (head == NULL)
	{
		head = NewNode;
		tail = NewNode;
	}
	else
	{
		tail->next = NewNode;
		tail = NewNode;
	}
}
void atmList::Display()
{


	if (head == NULL)
	{
		cout << "NO lnik exisit!!!!" << endl;
	}
	else if (head != NULL)
	{
		int index = 0;
		atmNode* curr = head;
		while (curr != NULL)
		{
			cout << "Node Number : " << index << endl;
			cout << "Amount Of transaction : " << curr->amountOftransaction << endl;
			cout << "card Number : " << curr->cardNumber << endl;
			cout << "Location Of Atm : " << curr->locationOfAtm << endl;
			cout << "Transactionit Date : " << curr->transactionitDate << endl;
			cout << "Transaction Time : " << curr->transactionTime << endl;

			curr = curr->next;
			index++;
		}
	}
}
void atmList::MarkAsDeposite(string& numberOfAccount, int& value, bool& need)
{
	string locationOfAtm, transactionitDate, transactionTime, amountOftransaction; int cardNumber;
	cout << "PLEASE ENTER THE NUMBER OF THE ACCOUNT : " << endl;
	cin >> numberOfAccount;
	cout << "PLEASE ENTER CARD NUMBER : ";
	cin >> cardNumber;
	cout << "PLEASE ENTER THE LOCATION OF THE ATM : ";
	cin >> locationOfAtm;
	cout << "PLEASE ENTER THE DATE AND THE TIME OF THE TRANSACTION : ";
	cin >> transactionitDate >> transactionTime;
	cout << "PLEASE ENTER THE VALUE OF THE TRANACTION  :";
	cin >> value;
	amountOftransaction = value;
	need = true;
	insert(transactionitDate, transactionTime, locationOfAtm, value, cardNumber);

}
void atmList::MarkAswithdraw(string& numberOfAccount, int& value, bool& need)
{
	string locationOfAtm, transactionitDate, transactionTime, amountOftransaction; int cardNumber;
	cout << "PLEASE ENTER THE NUMBER OF THE ACCOUNT : " << endl;
	cin >> numberOfAccount;
	cout << "PLEASE ENTER CARD NUMBER : ";
	cin >> cardNumber;
	cout << "PLEASE ENTER THE LOCATION OF THE ATM : ";
	cin >> locationOfAtm;
	cout << "PLEASE ENTER THE DATE AND THE TIME OF THE TRANSACTION : ";
	cin >> transactionitDate >> transactionTime;
	cout << "PLEASE ENTER THE VALUE OF THE ACCOUNT :";
	cin >> value;
	amountOftransaction = value;
	need = true;
	insert(transactionitDate, transactionTime, locationOfAtm, value, cardNumber);
}
void atmList::EnterData()
{
	string transactionitDate;
	string transactionTime;
	string locationOfAtm;
	int amountOftransaction;
	int cardNumber;
	cout << "PLEASE CUSTMER ENTER THE DAY OF THE TRANSACTIO " << endl;
	cin >> transactionitDate;
	cout << "PLEASE ENTER THE TIME OF THE TRANSACTION " << endl;
	cin >> transactionTime;
	cout << "PLEASE ENTER THE LOCATION OF THE ATM " << endl;
	cin >> locationOfAtm;
	cout << "PLEASE ENETR THE AMOUNT OF THE TRANSACTION " << endl;
	cin >> amountOftransaction;
	cout << "PLEASE ENTER THE CARD NUMBER " << endl;
	cin >> cardNumber;
	insert(transactionitDate, transactionTime, locationOfAtm, amountOftransaction, cardNumber);
}