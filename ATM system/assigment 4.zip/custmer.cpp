#include "custmer.h"
custmerNode::custmerNode()
{
	this->adress = "";
	this->arabicName = "";
	this->englishName = "";
	this->id = "";
	next = NULL;
}
custmerNode::custmerNode(string id, string englishName, string arabicName, string adress)
{
	this->id = id;
	this->englishName = englishName;
	this->arabicName = arabicName;
	this->adress = adress;
	next = NULL;
}
custmerList::custmerList()
{
	head = new custmerNode;
	tail = head;
}
void custmerList::deletFirst()
{
	custmerNode* curr = head;
	head = head->next;
	delete curr;
}
void custmerList::deleteLast()
{
	custmerNode* curr = head;
	custmerNode* prevoius = NULL;
	while (curr->next != NULL)
	{
		prevoius = curr;
		curr = curr->next;
	}
	tail = prevoius;
	prevoius->next = NULL;
	delete curr;
}
void custmerList::insert(string id, string englishName, string arabicName, string adress)
{
	custmerNode* NewNode = new custmerNode(id, englishName, arabicName, adress);
	if (head->id == "")
	{
		head = NewNode;
		tail = NewNode;
	}
	else
	{
		tail->next = NewNode;
		tail = NewNode;
	}
}
void custmerList::FillingTheList()
{
	string id;
	string englishName;
	string arabicName;
	string adress;
	string token;
	ifstream read;
	read.open("custmer.txt");
	if (read.fail())
	{
		cout << "failled to open the file" << endl;
		exit(1);
	}
	while (!read.eof())
	{
		for (int i = 0; i < 4; i++)
		{
			switch (i)
			{
			case 0:
				getline(read, token, ':');
				id = token;
				break;
			case 1:
				getline(read, token, ':');
				englishName = token;
				break;
			case 2:
				getline(read, token, ':');
				arabicName = token;
				break;
			case 3:
				getline(read, token, '\n');
				adress = token;
				if (id != "" || englishName != "" || arabicName != "" || adress != "")
				{
					insert(id, englishName, arabicName, adress);
				}
				break;
			default:
				cout << "ERROR OCURRED " << endl;
				exit(1);
				break;
			}
		}
	}
	read.close();
}
void custmerList::Display()
{
	if (head == NULL)
	{
		cout << "NO lnik exisit!!!!" << endl;
	}
	else if (head != NULL)
	{
		int index = 0;
		custmerNode* curr = head;
		while (curr != NULL)
		{
			cout << "Node Number : " << index << endl;
			cout << "Id : " << curr->id << endl;
			cout << "English Name :" << curr->englishName << endl;
			cout << "Arabic Name : " << curr->arabicName << endl;
			cout << "Adress :" << curr->adress << endl;
			curr = curr->next;
			index++;
		}
	}
}
custmerList::~custmerList()
{
	
}
void custmerList::changeDataINFile()
{
	custmerNode* curr = head;
	ofstream write;
	write.open("custmer.txt", ios::trunc);
	if (write.fail())
	{
		cout << "BABA" << endl;
		exit(1);
	}
	while (curr != NULL)
	{
		write << curr->id << ":" << curr->englishName << ":" << curr->arabicName << ":" << curr->adress << endl;
		curr = curr->next;
	}
	return;
}
bool custmerList::search()
{
	string id;
	cout << "Please enter your id :";
	cin >> id;
	custmerNode* curr = head;
	if (curr->id == id)
		return true;
	while (curr->next != NULL)
	{
		if (id == curr->id)
			return true;
		curr = curr->next;
	}
	return false;
}
void custmerList::addcustmer()
{
	custmerNode* curr = head; int choice = 0; string numberofaccount; string numberOfAccount; int value = 0; bool need; vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
	curr->accountList.FillingTheList();
	curr->accountList.Display();
	cout << "WELCOME TO OUR BANKING SUSTEM " << endl;
	cout << "IF YOU HAVE AN EXISTING ACCOUNT OR NEED TO CREATE ONE PLEASE PRESS 1 " << endl;
	cout << "IF YOU HAVE A CUSTMER ID OR YOU NEED TO MAKE ONE PRESS 2 " << endl;
	cin >> choice;
	switch (choice)
	{
	case 1:
		cout << "PLEASE ENTER THE NUMBER OF YOUR ACCOUNT :";
		cin >> numberofaccount;
		if (curr->accountList.checkIfExisit(numberofaccount) == false)
		{
			cout << "THERE IS NO SUCH ACCOUNT PLEASE TRY AGAIN !!" << endl;
			exit(1);
		}
		cout << "PLEASE TEL US WHAT DO YOU WANT :" << endl;
		cout << "1- CREATE ACCOUNT  " << endl;
		cout << "2-SHOW ACCOUNTS " << endl;
		cout << "3- SEARCH FOR A CERTAIN ACCOUNT " << endl;
		cout << "4- DEPOSITE" << endl;
		cout << "5- WITHDREW" << endl;
		cin >> choice;
		if (choice == 1)
		{
			curr->accountList.createAccount();
		}
		else if (choice == 2)
		{
			curr->accountList.Display();
		}
		else if (choice == 3)
		{
			curr->accountList.searchForNode();
		}
		else if (choice == 4)
		{
			curr->accountList.deposite(curr->AtmList);
		}
		else if (choice == 5)
		{
			curr->accountList.withdrew(curr->AtmList);
		}
		break;
	case 2:
		FillingTheList();
		Display();
		cout << "PLEASE CUSTMER IF YOU NEED TO CREATE A CUSTMER AND A NEW ACCOUNT PRESS 1" << endl;
		cout << "IF YOU ARE AN EXISTING CUSTMER PLEASE CHOOSE 2 " << endl;
		cin >> choice;
		if (choice == 1)
		{
			EnterData();
			changeDataINFile();
		}
		else if (choice == 2)
		{
			cout << "PLEASE IF YOU NEED TO DELETE CUSTMER PRESS 1" << endl;
			cout << "IF YOU NEED TO SEARCH FOR A CERTAIN CUSTMER PRESS 2" << endl;
			cin >> choice;
			if (choice == 1)
			{
				cout << "IF YOU WANT TO DELETE FIRST ACCOUNT CHOOSE 1" << endl;
				cout << "IF YOU WANT TO DELETE LAST ACCOUNT CHOOSE 2" << endl;
				cout << "IF YOU WANT TO DELETE A CERTAIN ACCOUNT CHOOSE 3" << endl;
				cin >> choice;
				if (choice == 1)
				{
					deletFirst();
					changeDataINFile();
				}
				else if (choice == 2)
				{
					deleteLast();
					changeDataINFile();
				}
				else if (choice == 3)
				{
					int pos;
					cout << "PLEASE ENTER THE POSITION YPU WANT TO DELETE :";
					cin >> pos;
					deletecutmer(pos);
					changeDataINFile();
				}
			}
			else if (choice == 2)
			{
				cout << boolalpha << search() << endl;
			}
		}

		break;
	default:
		break;
	}


}
void custmerList::deletecutmer(int pos)
{
	custmerNode* curr = new custmerNode;
	custmerNode* previous = new custmerNode;
	curr = head;
	for (int i = 0; i < pos; i++)
	{
		previous = curr;
		curr = curr->next;
	}
	previous->next = curr->next;
	delete curr;
	return;
}
void custmerList::EnterData()
{
	string adress, arabicname, englishname, id;
	cout << "PLEASE CUSTMER ENTER YOUR ADRESS : " << endl;
	cin >> adress;
	cout << "PLEASE CUSTMER ENTER YOUR ARABIC NAME : " << endl;
	cin >> arabicname;
	cout << "PLEASE CUSTMER ENTER YOUR ENGLISH NAME : " << endl;
	cin >> englishname;
	cout << "PLEASE CUSTMER ENTER YOUR ID  : " << endl;
	cin >> id;
	insert(id, englishname, arabicname, adress);
}