#include<iostream>
#include<fstream>
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"Atm.h"
#include"account.h"
#include"custmer.h"
using namespace std;

int main()
{
	custmerList myList;
	myList.addcustmer();
}
/*class card
{
	int NumberOfcard;
public:
	card()
	{
		this->NumberOfcard = 0;
	}
	card(int number)
	{
		this->NumberOfcard = number;
	}
	void	setNumber(int number)
	{
		this->NumberOfcard = number;
	}
	int getNumberOfCard()
	{
		return NumberOfcard;
	}
};
struct accountNode
{
	string numberOfTheAccount;
	string typeOfAccount;
	int balanceOfTheAccount;
	card arrayOfCards[2];
	accountNode* next;
	accountNode()
	{
		this->balanceOfTheAccount = 0;
		this->next = NULL;
		this->numberOfTheAccount = "";
		this->typeOfAccount = "";
		arrayOfCards[0].setNumber(0);
		arrayOfCards[1].setNumber(0);
	}
	accountNode(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount)
	{
		srand(time(0));
		int numberOfThefirstcard = 12345;
		int numberOfThesecondCard = 12345;
		this->balanceOfTheAccount = balanceOfTheAccount;
		this->next = NULL;
		this->numberOfTheAccount = numberOfTheAccount;
		this->typeOfAccount = typeOfAccount;
		this->arrayOfCards[0].setNumber(numberOfThefirstcard);
		this->arrayOfCards[1].setNumber(numberOfThesecondCard);
	}
};
class accountlist
{
private:
	accountNode* head;
	accountNode* tail;
public:
	//void changeDataINFile()
	//{
//		accountNode* curr = head;
//		ofstream write;
//		write.open("custmer.txt", ios::trunc);
//		if (write.fail())
//		{
//			cout << "Failed to open the file!!!" << endl;
//			exit(1);
//		}
//		while (curr != NULL)
//		{
//		write << curr->numberOfTheAccount << ":" << curr->typeOfAccount << ":" << curr->balanceOfTheAccount << endl;
//			curr = curr->next;
//		}
//		return;
//	}
	accountlist()
	{
		head = NULL;
		tail = NULL;
	}
	accountNode* searchForNode()
	{
		bool flag = false;
		string numberOfAccount;
		cout << "Please enter the number of your account : " << endl;
		cin >> numberOfAccount;
		accountNode* curr = head;
		while (curr->next != NULL)
		{
			if (numberOfAccount == curr->numberOfTheAccount)
			{
				cout << "Found !!!!!" << endl;
				flag = true;
				return curr;
			}
			curr = curr->next;
		}
		if (flag == false)
		{
			cout << "ACCOUNT NOT FOUND " << endl;
			exit(1);
		}
	}
	void deletecustmerInCertainPos(int pos)
	{
		accountNode* curr = new accountNode;
		accountNode* previous = new accountNode;
		curr = head;
		for (int i = 0; i < pos; i++)
		{
			previous = curr;
			curr = curr->next;
		}
		previous->next = curr->next;
		delete curr;
		return;
	}
	void FillingTheList()
	{
		string numberOfTheAccount;
		string typeOfAccount;
		int balanceOfTheAccount;
		string token;
		ifstream read;
		read.open("account.txt");
		if (read.fail())
		{
			cout << "Failled to open the file" << endl;
			exit(1);
		}
		while (!read.eof())
		{
			for (int i = 0; i < 3; i++)
			{
				switch (i)
				{
				case 0:
					//cout << i << endl;
					getline(read, token, ':');
					numberOfTheAccount = token;
					break;
				case 1:
					//cout << i << endl;
					getline(read, token, ':');
					typeOfAccount = token;
					break;
				case 2:
					getline(read, token, '\n');
					balanceOfTheAccount = stoi(token);
					//cout << i << endl;
					if (numberOfTheAccount != "" || typeOfAccount != "" || balanceOfTheAccount != 0)
					{
					//	cout << i << endl;
						insert(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
					}
					break;
				default:
					cout << "ERROR OCURRED " << endl;
					exit(1);
					break;
				}
			}
		}
		read.close();
	}
	void deletFirst()
	{
		accountNode* curr = head;
		head = head->next;
		delete curr;
	}
	void deleteLast()
	{
		accountNode* curr = head;
		accountNode* prevoius = NULL;
		while (curr->next != NULL)
		{
			prevoius = curr;
			curr = curr->next;
		}
		tail = prevoius;
		prevoius->next = NULL;
		delete curr;
	}
	bool checkIfExisit(string name)
	{
		accountNode* curr = head;
		while (curr != NULL)
		{
			if (curr->numberOfTheAccount == name)
			{
				return true;
			}
			curr = curr->next;
		}
		return false;
	}
	void createAccount()
	{
		int size = 0;
		vector <string> numberOfTheAccount;
		vector <string> typeOfAccount;
		vector <int> balanceOfTheAccount;
		string numberOfTheAccountEnterd;
		string typeOfAccountEntered;
		int balanceOfTheAccountEntered;
		createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		takingACCInfo(numberOfTheAccountEnterd, typeOfAccountEntered, balanceOfTheAccountEntered);
		if (checkIfExisit(numberOfTheAccountEnterd) == false)
		{
			insert(numberOfTheAccountEnterd, typeOfAccountEntered, balanceOfTheAccountEntered);
			numberOfTheAccount.push_back(numberOfTheAccountEnterd);
			typeOfAccount.push_back(typeOfAccountEntered);
			balanceOfTheAccount.push_back(balanceOfTheAccountEntered);
		}
		else if (checkIfExisit(numberOfTheAccountEnterd) == true)
		{
			cout << " ERROR THERE EXIXIST A ACCOUNT WITH THAT NUMBER !!!!! PLEASE TRY AGAIN " << endl;
			exit(1);
		}
		changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		return;
	}
	void changeDataInFile(vector <string> numberOfTheAccount, vector <string> typeOfAccount, vector <int> balanceOfTheAccount)
	{
		ofstream write; int counter = 0;
		write.open("account.txt", ios::trunc);
		for (int i = 0; i < numberOfTheAccount.size(); i++)
		{
			
			if(counter==numberOfTheAccount.size()-1)
			write << numberOfTheAccount[i] << ":" << typeOfAccount[i] << ":" << balanceOfTheAccount[i];
			else 
				write << numberOfTheAccount[i] << ":" << typeOfAccount[i] << ":" << balanceOfTheAccount[i] << endl;
			counter++;
		}
		return;
	}
	void withdrew(atmList object)
	{
		vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
		string numberOfAccount; int number = 0;
		bool check;
		createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		object.MarkAswithdraw(numberOfAccount,number, check);
		for (int i = 0; i < numberOfTheAccount.size(); i++)
		{
			if (numberOfTheAccount[i] == numberOfAccount && check == true)
			{
				balanceOfTheAccount[i] = (balanceOfTheAccount[i] - number);
				break;
			}
		}
		changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		return;
	}
	void deposite(atmList object)
	{
		vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
		string numberOfAccount; int number = 0;
		bool check;
		createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		object.MarkAsDeposite(numberOfAccount, number, check);
		for (int i = 0; i < 5; i++)
		{
			if (numberOfTheAccount[i] == numberOfAccount && check == true)
			{
				balanceOfTheAccount[i] = (balanceOfTheAccount[i] + number);
				break;
			}
		}
		changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		return;
	}
	void insert(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount)
	{
		accountNode* NewNode = new accountNode(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
		if (head == NULL)
		{
			head = NewNode;
			tail = NewNode;
		}
		else
		{
			tail->next = NewNode;
			tail = NewNode;
		}
	}
	void Display()
	{
		if (head == NULL)
		{
			cout << "NO lnik exisit!!!!" << endl;
		}
		else if (head != NULL)
		{
			int index = 0;
			accountNode* curr = head;
			while (curr != NULL)
			{
				cout << "Node Number : " << index << endl;
				cout << "Number Of The Account : " << curr->numberOfTheAccount << endl;
				cout << "Type Of Account : " << curr->typeOfAccount << endl;
				cout << "Balance Of The Account : " << curr->balanceOfTheAccount << endl;
				curr = curr->next;
				index++;
			}
		}
	}
	~accountlist()
	{
		//		free(head);
			//	free(tail);
	}
	void createNumberOfTheAccountVector(vector <string>& numberOfTheAccount, vector <string>& typeOfAccount, vector <int>& balanceOfTheAccount)
	{
		ifstream read;
		string token;
		read.open("account.txt");
		if (read.fail())
		{
			cout << "Failled to open the file " << endl;
			exit(1);
		}
		while (!read.eof())
		{
			for (int i = 0; i < 3; i++)
			{
				switch (i)
				{
				case 0:
					getline(read, token, ':');
					numberOfTheAccount.push_back(token);
					break;
				case 1:
					getline(read, token, ':');
					typeOfAccount.push_back(token);
					break;
				case 2:
					getline(read, token, '\n');
					balanceOfTheAccount.push_back(stoi(token));
					break;
				default:
					cout << "ERROR OCURRED " << endl;
					exit(1);
					break;
				}
			}
		}
		read.close();
		return;
	}
	void takingACCInfo(string& numberOfTheAccount, string& typeOfAccount, int& balanceOfTheAccount)
	{
		cout << "Please Custmer Enter the number Of your account please start from (100001) :  ";
		cin >> numberOfTheAccount;
		cout << "Please Custmer Enter the type of your Account please (VIP or normal) :  ";
		cin >> typeOfAccount;
		cout << "Please Custmer Enter the balance Of your Account of your Account :  ";
		cin >> balanceOfTheAccount;
		return;
	};
};
struct custmerNode
{
	string id;
	string englishName;
	string arabicName;
	string adress;
	custmerNode* next;
	atmList AtmList;
	accountlist accountList;
	custmerNode()
	{
		this->adress = "";
		this->arabicName = "";
		this->englishName = "";
		this->id = "";
		next = NULL;
	}
	custmerNode(string id, string englishName, string arabicName, string adress)
	{
		this->id = id;
		this->englishName = englishName;
		this->arabicName = arabicName;
		this->adress = adress;
		next = NULL;
	}
};
class custmerList
{
private:
	custmerNode* head;
	custmerNode* tail;
public:
	custmerList()
	{
		head =new custmerNode;
		tail = head;
	}
	void deletFirst()
	{
		custmerNode* curr = head;
		head = head->next;
		delete curr;
	}
	void deleteLast()
	{
		custmerNode* curr = head;
		custmerNode* prevoius = NULL;
		while (curr->next != NULL)
		{
			prevoius = curr;
			curr = curr->next;
		}
		tail = prevoius;
		prevoius->next = NULL;
		delete curr;
	}
	void insert(string id, string englishName, string arabicName, string adress)
	{
		custmerNode* NewNode = new custmerNode(id, englishName, arabicName, adress);
		if (head->id =="" )
		{
			head = NewNode;
			tail = NewNode;
		}
		else
		{
			tail->next = NewNode;
			tail = NewNode;
		}
	}
	void FillingTheList()
	{
		string id;
		string englishName;
		string arabicName;
		string adress;
		string token;
		ifstream read;
		read.open("custmer.txt");
		if (read.fail())
		{
			cout << "failled to open the file" << endl;
			exit(1);
		}
		while (!read.eof())
		{
			for (int i = 0; i < 4; i++)
			{
				switch (i)
				{
				case 0:
					getline(read, token, ':');
					id = token;
					break;
				case 1:
					getline(read, token, ':');
					englishName = token;
					break;
				case 2:
					getline(read, token, ':');
					arabicName = token;
					break;
				case 3:
					getline(read, token, '\n');
					adress = token;
					if (id != "" || englishName != "" || arabicName != "" || adress != "")
					{
						insert(id, englishName, arabicName, adress);
					}
					break;
				default:
					cout << "ERROR OCURRED " << endl;
					exit(1);
					break;
				}
			}
		}
		read.close();
	}
	void Display()
	{
		if (head == NULL)
		{
			cout << "NO lnik exisit!!!!" << endl;
		}
		else if (head != NULL)
		{
			int index = 0;
			custmerNode* curr = head;
			while (curr != NULL)
			{
				cout << "Node Number : " << index << endl;
				cout << "Id : " << curr->id << endl;
				cout << "English Name :" << curr->englishName << endl;
				cout << "Arabic Name : " << curr->arabicName << endl;
				cout << "Adress :" << curr->adress << endl;
				curr = curr->next;
				index++;
			}
		}
	}
	~custmerList()
	{
		//	free(head);
		//	free(tail);
	}
	//void FillingInfo(vector<string>& id, vector<string>& englishName, vector<string>& arabicName, vector<string>& adress)
//	{
//		ifstream read;
//		string token;
//		string line;
//		read.open("account.txt");
//		if (read.fail())
//		{
//			cout << "BABA" << endl;
//		}
//		while (getline(read, line))
//		{
//			for (int i = 0; i < 4; i++)
//			{
	//			switch (i)
//				{
//				case 0:
//					getline(read, token, ':');
//					id.push_back(token);
//					break;
//				case 1:
					//getline(read, token, ':');
					//englishName.push_back(token);
				//	break;
				//case 2:
				//	getline(read, token, ':');
				//	arabicName.push_back(token);
			//		break;
			//	case 3:
			//		getline(read, token, '\n');
			//		adress.push_back(token);
			//	default:
			//		cout << "ERROR OCURRED " << endl;
				//	exit(1);
			//		break;
			//	}
		//	}
	//	}
	//	read.close();
//	}
	void changeDataINFile()
	{
		custmerNode* curr = head;
		ofstream write;
		write.open("custmer.txt", ios::trunc);
		if (write.fail())
		{
			cout << "BABA" << endl;
			exit(1);
		}
		while (curr != NULL)
		{
			write << curr->id << ":" << curr->englishName << ":" << curr->arabicName << ":" << curr->adress << endl;
			curr = curr->next;
		}
		return;
	}
	bool search()
	{
		string id;
		cout << "Please enter your id :";
		cin >> id;
		custmerNode* curr = head;
		if (curr->id == id)
			return true;
		while (curr->next != NULL)
		{
			if (id == curr->id)
				return true;
			curr = curr->next;
		}
		return false;
	}
	void addcustmer()
	{
		custmerNode* curr = head; int choice = 0; string numberofaccount; string numberOfAccount; int value = 0; bool need; vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
		curr->accountList.FillingTheList();
		curr->accountList.Display();
		cout << "WELCOME TO OUR BANKING SUSTEM " << endl;
		cout << "IF YOU HAVE AN EXISTING ACCOUNT OR NEED TO CREATE ONE PLEASE PRESS 1 " << endl;
		cout << "IF YOU HAVE A CUSTMER ID OR YOU NEED TO MAKE ONE PRESS 2 " << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:
			cout << "PLEASE ENTER THE NUMBER OF YOUR ACCOUNT :";
			cin >> numberofaccount;
			if (curr->accountList.checkIfExisit(numberofaccount) == false)
			{
				cout << "THERE IS NO SUCH ACCOUNT PLEASE TRY AGAIN !!" << endl;
				exit(1);
			}
			cout << "PLEASE TEL US WHAT DO YOU WANT :" << endl;
			cout << "1- CREATE ACCOUNT  " << endl;
			cout << "2-SHOW ACCOUNTS " << endl;
			cout << "3- SEARCH FOR A CERTAIN ACCOUNT " << endl;
			cout << "4- DEPOSITE" << endl;
			cout << "5- WITHDREW" << endl;
			cin >> choice;
			if (choice == 1)
			{
				curr->accountList.createAccount();
			}
			else if (choice == 2)
			{
				curr->accountList.Display();
			}
			else if (choice == 3)
			{
				curr->accountList.searchForNode();
			}
			else if (choice == 4)
			{
				curr->accountList.deposite(curr->AtmList);
			}
			else if (choice == 5)
			{
			curr->accountList.withdrew(curr->AtmList);
			}
			break;
		case 2:
		   FillingTheList();
			Display();
			cout << "PLEASE CUSTMER IF YOU NEED TO CREATE A CUSTMER AND A NEW ACCOUNT PRESS 1" << endl;
			cout << "IF YOU ARE AN EXISTING CUSTMER PLEASE CHOOSE 2 " << endl;
			cin >> choice;
			if (choice == 1)
			{
				EnterData();
				changeDataINFile();
			}
			else if (choice == 2)
			{
				cout << "PLEASE IF YOU NEED TO DELETE CUSTMER PRESS 1" << endl;
				cout << "IF YOU NEED TO SEARCH FOR A CERTAIN CUSTMER PRESS 2" << endl;
				cin >> choice;
				if (choice == 1)
				{
					cout << "IF YOU WANT TO DELETE FIRST ACCOUNT CHOOSE 1" << endl;
					cout << "IF YOU WANT TO DELETE LAST ACCOUNT CHOOSE 2" << endl;
					cout << "IF YOU WANT TO DELETE A CERTAIN ACCOUNT CHOOSE 3" << endl;
					cin >> choice;
					if (choice == 1)
					{
						deletFirst();
						changeDataINFile();
					}
					else if (choice == 2)
					{
						deleteLast();
						changeDataINFile();
					}
					else if (choice == 3)
					{
						int pos;
						cout << "PLEASE ENTER THE POSITION YPU WANT TO DELETE :";
						cin >> pos;
						deletecutmer(pos);
						changeDataINFile();
					}
				}
				else if (choice == 2)
				{
				cout<<boolalpha<<search()<<endl;
				}
			}

			break;
		default:
			break;
		}


	}
	void deletecutmer(int pos)
	{
		custmerNode* curr = new custmerNode;
		custmerNode* previous = new custmerNode;
		curr = head;
		for (int i = 0; i < pos; i++)
		{
			previous = curr;
			curr = curr->next;
		}
		previous->next = curr->next;
		delete curr;
		return;
	}
	void EnterData()
	{
		string adress, arabicname, englishname, id;
		cout << "PLEASE CUSTMER ENTER YOUR ADRESS : " << endl;
		cin >> adress;
		cout << "PLEASE CUSTMER ENTER YOUR ARABIC NAME : " << endl;
		cin >> arabicname;
		cout << "PLEASE CUSTMER ENTER YOUR ENGLISH NAME : " << endl;
		cin >> englishname;
		cout << "PLEASE CUSTMER ENTER YOUR ID  : " << endl;
		cin >> id;
		insert(id, englishname, arabicname, adress);
	}
};
*/