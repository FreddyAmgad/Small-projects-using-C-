#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"Atm.h"
#include"account.h"
using namespace std;
struct custmerNode
{
	string id;
	string englishName;
	string arabicName;
	string adress;
	custmerNode* next;
	atmList AtmList;
	accountlist accountList;
	custmerNode();
	custmerNode(string id, string englishName, string arabicName, string adress);
};
class custmerList
{
private:
	custmerNode* head;
	custmerNode* tail;
public:
	custmerList();
	void deletFirst();
	void deleteLast();
	void insert(string id, string englishName, string arabicName, string adress);
	void FillingTheList();
	void Display();
	~custmerList();
	void changeDataINFile();
	bool search();
	void addcustmer();
	void deletecutmer(int pos);
	void EnterData();
};

