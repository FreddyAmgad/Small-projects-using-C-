#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
using namespace std;
struct atmNode
{
	string transactionitDate;
	string transactionTime;
	string locationOfAtm;
	int amountOftransaction;
	int cardNumber;
	atmNode* next;
	atmNode();
	atmNode(string transactionitDate, string transactionTime, string locationOfAtm, int amountOftransaction, int cardNumber);

};
class atmList
{
	atmNode* head, * tail;
public:
	atmList();
	void insert(string transactionitDate, string transactionTime, string locationOfAtm, int amountOftransaction, int cardNumber);
	void Display();
		void  MarkAsDeposite(string& numberOfAccount, int& value, bool& need);
		void MarkAswithdraw(string& numberOfAccount, int& value, bool& need);
		void EnterData();
};