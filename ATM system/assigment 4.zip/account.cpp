#include "account.h"
card::card()
{
	this->NumberOfcard = 0;
}
card::card(int number)
{
	this->NumberOfcard = number;
}
void	card::setNumber(int number)
{
	this->NumberOfcard = number;
}
int card::getNumberOfCard()
{
	return NumberOfcard;
}
accountNode::accountNode()
{
	this->balanceOfTheAccount = 0;
	this->next = NULL;
	this->numberOfTheAccount = "";
	this->typeOfAccount = "";
	arrayOfCards[0].setNumber(0);
	arrayOfCards[1].setNumber(0);
}
accountNode::accountNode(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount)
{
	srand(time(0));
	int numberOfThefirstcard = 12345;
	int numberOfThesecondCard = 12345;
	this->balanceOfTheAccount = balanceOfTheAccount;
	this->next = NULL;
	this->numberOfTheAccount = numberOfTheAccount;
	this->typeOfAccount = typeOfAccount;
	this->arrayOfCards[0].setNumber(numberOfThefirstcard);
	this->arrayOfCards[1].setNumber(numberOfThesecondCard);
}
accountlist::accountlist()
{
	head = NULL;
	tail = NULL;
}
accountNode* accountlist::searchForNode()
{
	bool flag = false;
	string numberOfAccount;
	cout << "Please enter the number of your account : " << endl;
	cin >> numberOfAccount;
	accountNode* curr = head;
	while (curr->next != NULL)
	{
		if (numberOfAccount == curr->numberOfTheAccount)
		{
			cout << "Found !!!!!" << endl;
			flag = true;
			return curr;
		}
		curr = curr->next;
	}
	if (flag == false)
	{
		cout << "ACCOUNT NOT FOUND " << endl;
		exit(1);
	}
}
void accountlist::deletecustmerInCertainPos(int pos)
{
	accountNode* curr = new accountNode;
	accountNode* previous = new accountNode;
	curr = head;
	for (int i = 0; i < pos; i++)
	{
		previous = curr;
		curr = curr->next;
	}
	previous->next = curr->next;
	delete curr;
	return;
}
void accountlist::FillingTheList()
{
	string numberOfTheAccount;
	string typeOfAccount;
	int balanceOfTheAccount;
	string token;
	ifstream read;
	read.open("account.txt");
	if (read.fail())
	{
		cout << "Failled to open the file" << endl;
		exit(1);
	}
	while (!read.eof())
	{
		for (int i = 0; i < 3; i++)
		{
			switch (i)
			{
			case 0:
				//cout << i << endl;
				getline(read, token, ':');
				numberOfTheAccount = token;
				break;
			case 1:
				//cout << i << endl;
				getline(read, token, ':');
				typeOfAccount = token;
				break;
			case 2:
				getline(read, token, '\n');
				balanceOfTheAccount = stoi(token);
				//cout << i << endl;
				if (numberOfTheAccount != "" || typeOfAccount != "" || balanceOfTheAccount != 0)
				{
					//	cout << i << endl;
					insert(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
				}
				break;
			default:
				cout << "ERROR OCURRED " << endl;
				exit(1);
				break;
			}
		}
	}
	read.close();
}
void accountlist::deletFirst()
{
	accountNode* curr = head;
	head = head->next;
	delete curr;
}
void accountlist::deleteLast()
{
	accountNode* curr = head;
	accountNode* prevoius = NULL;
	while (curr->next != NULL)
	{
		prevoius = curr;
		curr = curr->next;
	}
	tail = prevoius;
	prevoius->next = NULL;
	delete curr;
}
bool accountlist::checkIfExisit(string name)
{
	accountNode* curr = head;
	while (curr != NULL)
	{
		if (curr->numberOfTheAccount == name)
		{
			return true;
		}
		curr = curr->next;
	}
	return false;
}
void accountlist::createAccount()
{
	int size = 0;
	vector <string> numberOfTheAccount;
	vector <string> typeOfAccount;
	vector <int> balanceOfTheAccount;
	string numberOfTheAccountEnterd;
	string typeOfAccountEntered;
	int balanceOfTheAccountEntered;
	createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	takingACCInfo(numberOfTheAccountEnterd, typeOfAccountEntered, balanceOfTheAccountEntered);
	if (checkIfExisit(numberOfTheAccountEnterd) == false)
	{
		insert(numberOfTheAccountEnterd, typeOfAccountEntered, balanceOfTheAccountEntered);
		numberOfTheAccount.push_back(numberOfTheAccountEnterd);
		typeOfAccount.push_back(typeOfAccountEntered);
		balanceOfTheAccount.push_back(balanceOfTheAccountEntered);
	}
	else if (checkIfExisit(numberOfTheAccountEnterd) == true)
	{
		cout << " ERROR THERE EXIXIST A ACCOUNT WITH THAT NUMBER !!!!! PLEASE TRY AGAIN " << endl;
		exit(1);
	}
	changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	return;
}
void accountlist::changeDataInFile(vector <string> numberOfTheAccount, vector <string> typeOfAccount, vector <int> balanceOfTheAccount)
{
	ofstream write; int counter = 0;
	write.open("account.txt", ios::trunc);
	for (int i = 0; i < numberOfTheAccount.size(); i++)
	{

		if (counter == numberOfTheAccount.size() - 1)
			write << numberOfTheAccount[i] << ":" << typeOfAccount[i] << ":" << balanceOfTheAccount[i];
		else
			write << numberOfTheAccount[i] << ":" << typeOfAccount[i] << ":" << balanceOfTheAccount[i] << endl;
		counter++;
	}
	return;
}
void accountlist::withdrew(atmList object)
{
	vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
	string numberOfAccount; int number = 0;
	bool check;
	createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	object.MarkAswithdraw(numberOfAccount, number, check);
	for (int i = 0; i < numberOfTheAccount.size(); i++)
	{
		if (numberOfTheAccount[i] == numberOfAccount && check == true)
		{
			balanceOfTheAccount[i] = (balanceOfTheAccount[i] - number);
			break;
		}
	}
	changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	return;
}
void accountlist::deposite(atmList object)
{
	vector <string> numberOfTheAccount; vector <string> typeOfAccount; vector <int> balanceOfTheAccount;
	string numberOfAccount; int number = 0;
	bool check;
	createNumberOfTheAccountVector(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	object.MarkAsDeposite(numberOfAccount, number, check);
	for (int i = 0; i < 5; i++)
	{
		if (numberOfTheAccount[i] == numberOfAccount && check == true)
		{
			balanceOfTheAccount[i] = (balanceOfTheAccount[i] + number);
			break;
		}
	}
	changeDataInFile(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	return;
}
void accountlist::insert(string numberOfTheAccount, string typeOfAccount, int balanceOfTheAccount)
{
	accountNode* NewNode = new accountNode(numberOfTheAccount, typeOfAccount, balanceOfTheAccount);
	if (head == NULL)
	{
		head = NewNode;
		tail = NewNode;
	}
	else
	{
		tail->next = NewNode;
		tail = NewNode;
	}
}
void accountlist::Display()
{
	if (head == NULL)
	{
		cout << "NO lnik exisit!!!!" << endl;
	}
	else if (head != NULL)
	{
		int index = 0;
		accountNode* curr = head;
		while (curr != NULL)
		{
			cout << "Node Number : " << index << endl;
			cout << "Number Of The Account : " << curr->numberOfTheAccount << endl;
			cout << "Type Of Account : " << curr->typeOfAccount << endl;
			cout << "Balance Of The Account : " << curr->balanceOfTheAccount << endl;
			curr = curr->next;
			index++;
		}
	}
}
accountlist::~accountlist() {

}
void accountlist::createNumberOfTheAccountVector(vector <string>& numberOfTheAccount, vector <string>& typeOfAccount, vector <int>& balanceOfTheAccount)
{
	ifstream read;
	string token;
	read.open("account.txt");
	if (read.fail())
	{
		cout << "Failled to open the file " << endl;
		exit(1);
	}
	while (!read.eof())
	{
		for (int i = 0; i < 3; i++)
		{
			switch (i)
			{
			case 0:
				getline(read, token, ':');
				numberOfTheAccount.push_back(token);
				break;
			case 1:
				getline(read, token, ':');
				typeOfAccount.push_back(token);
				break;
			case 2:
				getline(read, token, '\n');
				balanceOfTheAccount.push_back(stoi(token));
				break;
			default:
				cout << "ERROR OCURRED " << endl;
				exit(1);
				break;
			}
		}
	}
	read.close();
	return;
}
void accountlist::takingACCInfo(string& numberOfTheAccount, string& typeOfAccount, int& balanceOfTheAccount)
{
	cout << "Please Custmer Enter the number Of your account please start from (100001) :  ";
	cin >> numberOfTheAccount;
	cout << "Please Custmer Enter the type of your Account please (VIP or normal) :  ";
	cin >> typeOfAccount;
	cout << "Please Custmer Enter the balance Of your Account of your Account :  ";
	cin >> balanceOfTheAccount;
	return;
};