#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
#include"name.h"
#include"Person.h"
#include"Patient.h"
using namespace std;
bool operator<(const std::pair<int, patient>& a, const pair<int, patient>& b);
class doctor :public person
{
	bool urgencyPresence = false;
	bool regular = false;
	patient arrayOFPatients[15];
public:
	pair<bool, patient> appointment[15];
	priority_queue<pair<int, patient>, vector<pair<int, patient>>, greater<pair<int, patient>>>pq;
	void serve(doctor dr);
	void setPrecence(bool t);
	bool getPresence();
		void setregular(bool t);
	bool getregular();
	doctor();
	doctor(string first, string last, string id);
	void steNameFirst(string first);
	void steNameLast(string last);
	void setId(string id);
	Name getTheName();
	string getId();
	bool checkDrAvailble(int hour);
	void setpatient(patient p, int hours);
	patient getPatient(int hours);
	void fillarrayOfApptitment(int hours, patient p);
	void changeQue(doctor& dr, string id);
	void changearray(doctor& dr, string id);
};

