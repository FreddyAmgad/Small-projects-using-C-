#include "Doctor.h"
bool operator<(const std::pair<int, patient>& a, const pair<int, patient>& b)
{
	return a.first < b.first;
}
void doctor::serve(doctor dr)
{

	if (dr.getPresence())
	{
		while (!dr.pq.empty())
		{
			pair<int, patient>served = dr.pq.top();
			dr.pq.pop();
			cout << "DR : " << dr.getTheName().first << "  SERVED AS A PRIORTY : " << served.second.getTheName().first << " " << served.second.getTheName().last << "\n\n";
		}
	}
	if (dr.getregular())
	{
		for (int j = 0; j < 15; j++)
		{
			if (dr.appointment[j].second.getId() != "")
				cout << "DR : " << dr.getTheName().first << "  SERVED AFTER : " << dr.appointment[j].second.getTheName().first << " " << dr.appointment[j].second.getTheName().last << "\n\n";
		}
	}


}
void doctor::setPrecence(bool t)
{
	this->urgencyPresence = t;
}
bool doctor::getPresence()
{
	return urgencyPresence;
}
void doctor::setregular(bool t)
{
	this->regular = t;
}
bool doctor::getregular()
{
	return regular;
}
doctor::doctor()
{
	for (int i = 0; i < 15; i++)
	{
		appointment[i].first = false;
	}

}
doctor::doctor(string first, string last, string id)
{
	this->name.first = first;
	this->name.last = last;
	this->id = id;
}
void doctor::steNameFirst(string first)
{
	this->name.first = first;
}
void doctor::steNameLast(string last)
{
	this->name.last = last;
}
void doctor::setId(string id)
{
	this->id = id;
}
Name doctor::getTheName()
{
	return name;
}
string doctor::getId()
{
	return id;
}
bool doctor::checkDrAvailble(int hour)
{
	if (appointment[hour].first == false)
		return true;
	else
		return false;
}
void doctor::setpatient(patient p, int hours)
{
	this->arrayOFPatients[hours] = p;
}
patient doctor::getPatient(int hours)
{
	return arrayOFPatients[hours];
}
void doctor::fillarrayOfApptitment(int hours, patient p)
{
	appointment[hours].first = true;
	appointment[hours].second = p;
}
void doctor::changeQue(doctor& dr, string id)
{
	if (dr.pq.empty())
		return;
	vector < pair<int, patient>>v(15);
	pair<int, patient> curr;
	curr = dr.pq.top();
	while (!dr.pq.empty())
	{
		curr = dr.pq.top();
		dr.pq.pop();
		v.push_back(curr);
	}
	for (int i = 0; i < v.size(); i++)
	{
		if (v[i].second.getId() != "")
		{
			if (v[i].second.getId() != id)
				dr.pq.push(v[i]);
			else if (v[i].second.getId() == id)
			{
				v[i].first = false;
			}
		}
	}
	return;
}
void doctor::changearray(doctor& dr, string id)
{
	for (int i = 0; i < 15; i++)
	{
		if (dr.appointment[i].second.getId() == id)
		{
			patient p;
			dr.appointment[i].first = false;
			dr.appointment[i].second = p;
			return;
		}
	}
}