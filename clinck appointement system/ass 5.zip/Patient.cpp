#include "Patient.h"
void patient::setPriority(int pririty)
{
	this->priority = pririty;
}
int  patient::getpririty()
{
	return priority;
}
patient::patient()
{
	this->email = "";
	this->phoneNumber = 0;
}
patient::patient(string first, string last, string email, string id, int phonenumber)
{
	this->name.first = first;
	this->name.last = last;
	this->email = email;
	this->id = id;
	this->phoneNumber = phonenumber;
}
void  patient::steNameFirst(string first)
{
	this->name.first = first;
}
void  patient::steNameLast(string last)
{
	this->name.last = last;
}
void  patient::setId(string id)
{
	this->id = id;
}
void  patient::setEmail(string email)
{
	this->email = email;
}
void  patient::setPhoneNumber(int number)
{

	this->phoneNumber = number;
}
int  patient::getPhoneNumber()
{
	return phoneNumber;
}
string  patient::getEmail()
{
	return email;
}
Name  patient::getTheName()
{
	return name;
}
string  patient::getId()
{
	return id;
}