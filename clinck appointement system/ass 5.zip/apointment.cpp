#include "apointment.h"
aappointement::aappointement()
{
	this->sizeOfDoctors = 0;
	this->sizeOfPatients = 0;
}
void aappointement::SizeOfArrayOfPaitients()
{
	ifstream read; string token;
	read.open("paitient.txt");
	if (read.fail())
	{
		cout << "FAILLED TO OPEN PATIENT FILE" << endl;
		exit(1);
	}
	while (getline(read, token))
	{
		sizeOfPatients++;
	}
	return;
}
void aappointement::SizeOfArrayOfDoctors()
{
	ifstream read; string token;
	read.open("doctor.txt");
	if (read.fail())
	{
		cout << "FAILLED TO OPEN PATIENT FILE" << endl;
		exit(1);
	}
	while (getline(read, token))
	{
		sizeOfDoctors++;
	}
	return;
}
void aappointement::FillingTheArrayOfPaitients()
{
	SizeOfArrayOfPaitients();
	arrayOfpatients = new patient[sizeOfPatients];
	ifstream read; int index = 0; string token; string line;
	read.open("paitient.txt");
	if (read.fail())
	{
		cout << "FAILLED TO OPEN PATIENT FILE" << endl;
		exit(1);
	}
	while (!read.eof())
	{
		for (int i = 0; i < 5; i++)
		{
			switch (i)
			{
			case 0:
				getline(read, token, ':');
				arrayOfpatients[index].steNameFirst(token);
				break;
			case 1:
				getline(read, token, ':');
				arrayOfpatients[index].steNameLast(token);
				break;
			case 2:
				getline(read, token, ':');
				arrayOfpatients[index].setId(token);
				break;
			case 3:
				getline(read, token, ':');
				arrayOfpatients[index].setEmail(token);
				break;
			case 4:
				getline(read, token, '\n');
				arrayOfpatients[index].setPhoneNumber(stoi(token));
				break;

			default:
				cout << "ERROR HAPPENED AT THE SWITCH STAMTENT OF THE PATIENCE " << endl;
				exit(1);
			}
		}
		index++;
	}
}
void aappointement::FillingTheArrayOfDoctors()
{
	SizeOfArrayOfDoctors();
	ifstream read; int index = 0; string token; string line;
	arrayOfDoctors = new doctor[sizeOfDoctors];
	read.open("doctor.txt");
	if (read.fail())
	{
		cout << "FAILLED TO OPEN PATIENT FILE" << endl;
		exit(1);
	}
	while (!read.eof())
	{
		for (int i = 0; i < 3; i++)
		{
			switch (i)
			{
			case 0:
				getline(read, token, ':');
				arrayOfDoctors[index].steNameFirst(token);
				break;
			case 1:
				getline(read, token, ':');
				arrayOfDoctors[index].steNameLast(token);
				break;
			case 2:
				getline(read, token, '\n');
				arrayOfDoctors[index].setId(token);
				break;


			default:
				cout << "ERROR HAPPENED AT THE SWITCH STAMTENT OF THE PATIENCE " << endl;
				exit(1);
			}
		}
		index++;
	}
	return;
}
void aappointement::Display()
{
	cout << "PATIENT INFO IN FILE:" << endl;
	for (int i = 0; i < sizeOfDoctors; i++)
	{
		cout << " DR : " << arrayOfDoctors[i].getTheName().first << " ARRAY " << endl;
		for (int j = 0; j < 15; j++)
		{
			cout << arrayOfDoctors[i].appointment[j].first << " , ";
		}
		cout << "\n\n";
	}
}
void aappointement::makeAppointment(int& count)
{
	if (count == 0)
	{
		FillingTheArrayOfPaitients();
		FillingTheArrayOfDoctors();
		count++;
	}
	int choice;
	cout << "IF YOU ARE A NEW CUSTMER CLICK 1" << endl;
	cout << "IF YOU ARE AN EXISITING CUSTMER CLICK 2" << endl;
	cin >> choice;
	if (choice == 2)
	{

		string id;
		cout << "PLEASE ENTER YOUR ID (MAKE SURE TO ENTER IT CORRECTLY) : " << endl;
		cin >> id;
		patient temp = searcForPreviousPatientForNormal(id);
		cout << "IF YOU WANT AN URGENT APPOINTMENT PRESS 1 " << endl;
		cout << "IF YOU WANT A REGULAR APPOINTMENT PRESS 2 " << endl;
		cin >> choice;
		if (choice == 1)
		{
			urgentRegestirationPreviousPatient(id, temp);//t3del law mlan a3ml eh 

		}
		else if (choice == 2)
		{
			int time;
			cout << "PLEASE ENTER THE TIME FROM 9 TO 23 :";
			cin >> time;
			rgularRegestration(time, temp);
			Display();
		}

	}
	else if (choice == 1)
	{
		string first, last, email, id;
		int phonenumb;

		cout << "PLEASE ENTER YOUR FIRST NAME " << endl;
		cin >> first;
		cout << "PLEASE ENTER YOUR LAST NAME " << endl;
		cin >> last;
		cout << "PLEASE ENTER YOUR EMAIL " << endl;
		cin >> email;
		cout << "PLEASE ENTER YOUR PHONE NUMBER " << endl;
		cin >> phonenumb;
		cout << "PLEASE ENTER YOUR ID " << endl;
		cin >> id;
		patient Npatient(first, last, email, id, phonenumb);
		changeDataInFile(Npatient);
		cout << "IF YOU WANT AN URGENT APPOINTMENT PRESS 1 " << endl;
		cout << "IF YOU WANT A REGULAR APPOINTMENT PRESS 2 " << endl;
		cin >> choice;
		if (choice == 1)
		{
			urgentRegestirationPreviousPatient(id, Npatient);

		}
		else if (choice == 2)
		{
			int time;
			cout << "PLEASE ENTER THE TIME FROM 9 TO 23 :";
			cin >> time;
			rgularRegestration(time, Npatient);
		}
	}
}
bool aappointement::checkIfPatientExist(patient p)
{
	for (int i = 0; i < sizeOfPatients; i++)
	{
		if (arrayOfpatients[i].getId() == p.getId())
		{
			return true;
		}
	}

	return false;
}
void aappointement::changeDataInFile(patient p)
{
	if (checkIfPatientExist(p) == false)
	{
		ofstream write;
		write.open("paitient.txt", ios::trunc);
		if (write.fail())
		{
			cout << "FAILLED TO OPEN PATIENT FILE" << endl;
			exit(1);
		}
		for (int i = 0; i < sizeOfPatients; i++)
		{
			write << arrayOfpatients[i].getTheName().first << ":" << arrayOfpatients[i].getTheName().last << ":" << arrayOfpatients[i].getId() << ":" << arrayOfpatients[i].getEmail() << ":" << arrayOfpatients[i].getPhoneNumber() << endl;
		}
		write << p.getTheName().first << ":" << p.getTheName().last << ":" << p.getId() << ":" << p.getEmail() << ":" << p.getPhoneNumber();
		write.close();
		return;
	}
}
int aappointement::searchForFreeDr(int& time)
{
	for (int i = 0; i < sizeOfDoctors; i++)
	{
		if (arrayOfDoctors[i].checkDrAvailble(time))
		{
			return i;
		}
	}
	for (int i = 0; i < sizeOfDoctors; i++)
	{
		for (int j = time; j < 15; j++)
		{
			if (arrayOfDoctors[i].checkDrAvailble(j))
			{
				time = j;
				return i;
			}
		}
	}
	cout << "NO SLOTS AVAILBLE TRY TOMMOROW !!!" << endl;
	exit(1);
	return -1;
}
patient aappointement::searcForPreviousPatientForNormal(string id)
{
	bool flag = false;
	for (int i = 0; i < sizeOfPatients; i++)
	{
		if (arrayOfpatients[i].getId() == id)
			return arrayOfpatients[i];
	}
	if (flag == false)
	{
		cout << " PATIENT NOT FOUND !!!!!" << endl;
		exit(1);
	}
}
void aappointement::rgularRegestration(int time, patient p)
{
	time = time - 9;
	int indexOfDr = searchForFreeDr(time);
	arrayOfDoctors[indexOfDr].fillarrayOfApptitment(time, p);
	arrayOfDoctors[indexOfDr].setpatient(p, time);
	arrayOfDoctors[indexOfDr].setregular(true);

	return;
}
void aappointement::urgentRegestirationPreviousPatient(string id, patient p)
{
	int priority = 0;
	cout << "PLEASE ENTER THE HOUR THAT YOU NEED FROM 9 TO 23 :";
	cin >> priority;
	priority = priority - 9;
	p.setPriority(priority);
	int indexOfDr = searchForFreeDr(priority);
	arrayOfDoctors[indexOfDr].fillarrayOfApptitment(priority, p);
	arrayOfDoctors[indexOfDr].setpatient(p, priority);
	arrayOfDoctors[indexOfDr].pq.push({ priority,p });
	arrayOfDoctors[indexOfDr].setPrecence(true);
	return;

}
void aappointement::mainFunction()
{
	int choice = 1; int count = 0;
	while (choice != 0)
	{
		makeAppointment(count);
		cout << "\n\n\nIF YOU WANT TO MAKE ANOTHER APPOINTMENT CLICK 1 ELSE CLICK 0" << endl;
		cin >> choice;
	}
	cout << "\n\n\n\n";
	cout << "DO YOU WANT TO DELETE YOUR APPPOINTMENT IF SO PRESS 1 ELSE PRESS 2" << endl;
	cin >> choice;
	if (choice == 1)
	{
		string id;
		cout << "IF YOU WANT TO DELETE URGENT APOINTMENT PRESS 1" << endl;
		cout << "IF YOU WANT TO DELETE REGULAR  APOINTMENT PRESS 2" << endl;
		cin >> choice;
		if (choice == 1)
		{
			cout << "PLEASE ENTER YOUR ID : "; cin >> id;
			for (int i = 0; i < sizeOfDoctors; i++)
			{
				arrayOfDoctors[i].changeQue(arrayOfDoctors[i], id);
			}
		}
		else if (choice == 2)
		{
			cout << "PLEASE ENTER YOUR ID : "; cin >> id;
			for (int i = 0; i < sizeOfDoctors; i++)
			{
				arrayOfDoctors[i].changearray(arrayOfDoctors[i], id);
			}
		}
	}

	for (int i = 0; i < sizeOfDoctors; i++)
		arrayOfDoctors[i].serve(arrayOfDoctors[i]);


}