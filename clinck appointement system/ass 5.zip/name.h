#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
using namespace std;
struct Name
{
	string first;
	string last;
	Name();
	Name(string first, string last);
};
