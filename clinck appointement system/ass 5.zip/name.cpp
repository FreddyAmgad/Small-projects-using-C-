#include "name.h"
Name::Name()
{
	first = "";
	last = "";
}
Name::Name(string first, string last)
{
	this->first = first;
	this->last = last;
}