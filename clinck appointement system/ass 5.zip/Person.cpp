#include "Person.h"
person::person()
{
	this->name.first = "";
	this->name.last = "";
	this->id = "";
}
void person::steName(string first, string last, string id)
{
	this->name.first = first;
	this->name.last = last;
	this->id = id;
}
void person::setId(string id)
{
	this->id = id;
}
Name person::getTheName()
{
	return name;
}
string person::getId()
{
	return id;
}