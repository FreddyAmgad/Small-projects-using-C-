#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
#include"name.h"
using namespace std;
class person
{
protected:
	Name name;
	string id;
public:
	person();
	void steName(string first, string last, string id);
	void setId(string id);
	Name getTheName();
	string getId();
};
