#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
#include"name.h"
#include"Person.h"
#include"Patient.h"
#include"Doctor.h"
#include"apointment.h"
using namespace std;
int main()
{
	aappointement object;
	object.mainFunction();
	return 0;
}