#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
#include"name.h"
#include"Person.h"
class patient :public person
{
	string email;
	int phoneNumber;
	int priority;
public:
	void setPriority(int pririty);
	int getpririty();
	patient();
	patient(string first, string last, string email, string id, int phonenumber);
	void steNameFirst(string first);
	void steNameLast(string last);
	void setId(string id);
	void setEmail(string email);
	void setPhoneNumber(int number);
	int getPhoneNumber();
	string getEmail();
	Name getTheName();
	string getId();
};

