#pragma once
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<queue>
#include"name.h"
#include"Person.h"
#include"Patient.h"
#include"Doctor.h"
using namespace std;
class aappointement
{

	int sizeOfPatients, sizeOfDoctors;
public:

	patient* arrayOfpatients;
	doctor* arrayOfDoctors;
	aappointement();
	void SizeOfArrayOfPaitients();
	void SizeOfArrayOfDoctors();
	void FillingTheArrayOfPaitients();
	void FillingTheArrayOfDoctors();
	void Display();
	void makeAppointment(int& count);
	bool checkIfPatientExist(patient p);
	void changeDataInFile(patient p);
	int searchForFreeDr(int& time);
	patient searcForPreviousPatientForNormal(string id);
	void rgularRegestration(int time, patient p);
	void urgentRegestirationPreviousPatient(string id, patient p);
	void mainFunction();
};


